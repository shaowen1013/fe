package com.shaowen.fe.controller;

import com.shaowen.fe.service.MachineWorkTimeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/** 對應 2-5.Machine_WorkTime.aspx（機況處理工時，個人／全體）。 */
@RestController
@RequestMapping("/api/machine-worktime")
public class MachineWorkTimeController {

    @Autowired
    private MachineWorkTimeService workTimeService;

    @GetMapping("/personal")
    public ResponseEntity<Map<String, Object>> personal(@RequestParam Map<String, String> params) {
        return ResponseEntity.ok(workTimeService.searchPersonal(params));
    }

    @GetMapping("/all")
    public ResponseEntity<List<Map<String, Object>>> all(@RequestParam Map<String, String> params) {
        return ResponseEntity.ok(workTimeService.searchAll(params));
    }
}
