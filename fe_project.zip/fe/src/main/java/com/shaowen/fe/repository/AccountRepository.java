package com.shaowen.fe.repository;

import com.shaowen.fe.entity.Account;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AccountRepository extends JpaRepository<Account, String> {

    /**
     * 依工號查詢啟用中的帳號。
     * 使用 Spring Data 衍生查詢（內部自動採用參數化 PreparedStatement），
     * 取代原本 C# 程式碼中以字串拼接組成 SQL 造成的 SQL Injection 風險。
     */
    Optional<Account> findByUserIdAndAccountActiveTrue(String userId);
}
