package com.shaowen.fe.service;

import java.util.List;
import java.util.Map;

/**
 * 首頁三個查詢功能的服務介面。
 * 對應 1.Home.aspx.cs 的三個 func 方法。
 */
public interface HomeService {

    /** 取得人員下拉清單（AMHS 部門、啟用中帳號） */
    List<String> getUserList();

    /**
     * 未結案之機況（funcMachineNotFinished）
     * @param userName  人員姓名
     * @param sortField 排序欄位（白名單驗證）
     * @param sortDir   ASC / DESC
     */
    List<Map<String, Object>> getMachineNotFinished(String userName, String sortField, String sortDir);

    /**
     * 未處理之PM項目（funcPM_NotFinished）
     */
    List<Map<String, Object>> getPMNotFinished(String userName, String sortField, String sortDir);

    /**
     * 未結案之提案改善項目（funcProposal_NotFinished）
     */
    List<Map<String, Object>> getProposalNotFinished(String userName, String sortField, String sortDir);
}
