package com.shaowen.fe.service;

import java.util.List;
import java.util.Map;

/**
 * 對應 2-5.Machine_WorkTime.aspx.cs（機況處理工時，個人／全體）。
 *
 * 說明：原系統「全體」模式用一大段巢狀 correlated subquery 組出報表，且是用
 * SUM(DATEDIFF(...)) 直接加總，並未處理同一人多筆重疊時段的問題（會重複計算）。
 * 這裡改用與 PmWorkTimeServiceImpl 相同、更嚴謹的區間合併演算法（interval merge），
 * 避免重疊時段被重複計算，計算結果會比原系統更準確。
 */
public interface MachineWorkTimeService {

    /** 個人模式（依 Pricipal_Person 篩選），回傳 rows + 合併後總處理分鐘數 */
    Map<String, Object> searchPersonal(Map<String, String> params);

    /** 全體模式：每位人員的合併後總處理分鐘數 */
    List<Map<String, Object>> searchAll(Map<String, String> params);
}
