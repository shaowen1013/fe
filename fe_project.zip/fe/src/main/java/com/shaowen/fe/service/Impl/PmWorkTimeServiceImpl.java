package com.shaowen.fe.service.Impl;

import com.shaowen.fe.service.PmWorkTimeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * PmWorkTimeService 的具體實作。
 *
 * 重點：原系統的 funcCountTime() 是用「逐分鐘標記再加總」的方式計算重疊區間合併後的總分鐘數，
 * 這裡改用排序後合併區間（interval merge）演算法達到完全相同的結果，效能更好也更易讀。
 */
@Service
public class PmWorkTimeServiceImpl implements PmWorkTimeService {

    @Autowired
    private JdbcTemplate jdbc;

    // ---------------------------------------------------------------- 個人模式

    @Override
    public Map<String, Object> searchPersonal(Map<String, String> p) {
        StringBuilder where = new StringBuilder(" WHERE Table_PM.Active = 1 ");
        List<Object> args = new ArrayList<>();

        String startTime = orDefault(p.get("startTime"), "1990-01-01 00:00:00");
        String endTime = orDefault(p.get("endTime"), "2999-01-01 00:00:00");
        where.append(" AND Table_PM.StartTime BETWEEN ? AND ? ");
        args.add(startTime);
        args.add(endTime);

        appendUserNameFilter(p, where, args);

        String tableType = trim(p.get("tableType"));
        if (!tableType.isEmpty() && !"00".equals(tableType) && !"0".equals(tableType)) {
            where.append(" AND Table_PM.TableType = ? ");
            args.add(Integer.parseInt(tableType));
        }
        String tableDep = trim(p.get("tableDep"));
        if (!tableDep.isEmpty() && !"0".equals(tableDep)) {
            where.append(" AND CAST(Table_PM.tableDep AS CHAR) LIKE CONCAT(?, '%') ");
            args.add(tableDep);
        }
        String statusNow = trim(p.get("statusNow"));
        if (!statusNow.isEmpty() && !"0".equals(statusNow)) {
            where.append(" AND Table_PM.StatusNow = ? ");
            args.add(Integer.parseInt(statusNow));
        }
        String isErr = p.get("isErr");
        if ("1".equals(isErr) || "0".equals(isErr)) {
            where.append(" AND Table_PM.isErr = ? ");
            args.add("1".equals(isErr));
        }
        String isErrClear = p.get("isErrClear");
        if ("1".equals(isErrClear) || "0".equals(isErrClear)) {
            where.append(" AND Table_PM.isErrClear = ? ");
            args.add("1".equals(isErrClear));
        }

        String listSql = """
                SELECT Table_PM.Sequence, Table_PM_TableType.TableType_Chinese AS tableTypeText,
                       Table_PM.FabPrincipal, Table_PM.StartTime, Table_PM.FinishTime,
                       TIMESTAMPDIFF(MINUTE, Table_PM.StartTime, Table_PM.FinishTime) AS workMinutes,
                       Table_PM.EQID, Table_PM.StopEQReason, Table_PM.PMPeople,
                       Table_PM_StatusNow.StatusNow_Chinese AS statusNowText,
                       Table_PM.isErr, Table_PM.isErrClear,
                       Table_PM.StartTime_RealPM, Table_PM.FinishTime_RealPM
                FROM Table_PM
                LEFT JOIN Table_PM_TableType ON Table_PM_TableType.TableType_Sequence = Table_PM.TableType
                LEFT JOIN Table_PM_StatusNow ON Table_PM_StatusNow.StatusNow_Sequence = Table_PM.StatusNow
                """ + where + " ORDER BY Table_PM.Sequence DESC";

        List<Map<String, Object>> rows = jdbc.queryForList(listSql, args.toArray());

        int totalFiltered = mergedMinutes(rows, "StartTime", "FinishTime");
        int totalRealPM = mergedMinutes(rows, "StartTime_RealPM", "FinishTime_RealPM");

        Map<String, Object> result = new HashMap<>();
        result.put("rows", rows);
        result.put("totalMinutesFiltered", totalFiltered);
        result.put("totalMinutesRealPM", totalRealPM);
        return result;
    }

    private void appendUserNameFilter(Map<String, String> p, StringBuilder where, List<Object> args) {
        boolean useDeptMembers = "true".equals(p.get("useDeptMembers"));
        String userName = trim(p.get("userName"));

        if (useDeptMembers && !userName.isEmpty()) {
            List<String> members = getDepMembers(userName);
            if (members.isEmpty()) {
                where.append(" AND 1 = 0 ");
                return;
            }
            where.append(" AND (");
            for (int i = 0; i < members.size(); i++) {
                where.append(i == 0 ? "Table_PM.PMPeople LIKE ?" : " OR Table_PM.PMPeople LIKE ?");
                args.add("%" + members.get(i) + "%");
            }
            where.append(") ");
        } else if ("0".equals(userName)) {
            where.append(" AND Table_PM.PMPeople IS NULL ");
        } else if (!userName.isEmpty()) {
            where.append(" AND Table_PM.PMPeople LIKE ? ");
            args.add("%" + userName + "%");
        }
    }

    // ---------------------------------------------------------------- 全體模式

    @Override
    public List<Map<String, Object>> searchAll(Map<String, String> p) {
        String startTime = orDefault(p.get("startTime"), "1990-01-01 00:00:00");
        String endTime = orDefault(p.get("endTime"), "2999-01-01 00:00:00");
        String tableType = trim(p.get("tableType"));

        Integer standardMinutes = jdbc.queryForObject(
                "SELECT IFNULL(SUM(`WorkTime(Min)`), 1) FROM WorkDate WHERE WorkDate BETWEEN ? AND ?",
                Integer.class, startTime.substring(0, 10), endTime.substring(0, 10));
        if (standardMinutes == null || standardMinutes == 0) standardMinutes = 1;

        List<Map<String, Object>> people = jdbc.queryForList("""
                SELECT Group_4 AS dep, User_Name AS userName
                FROM AccountTable_Active
                WHERE Group_3 != '0' AND (Job_Title = 'Leader' OR Job_Title IS NULL)
                ORDER BY Group_4
                """);

        List<Map<String, Object>> result = new ArrayList<>();

        for (Map<String, Object> person : people) {
            String userName = (String) person.get("userName");

            List<Map<String, Object>> rows = fetchPmRowsForUser(userName, startTime, endTime, tableType, null);
            List<Map<String, Object>> rowsAmhs = fetchPmRowsForUser(userName, startTime, endTime, tableType, "1");
            List<Map<String, Object>> rowsAint = fetchPmRowsForUser(userName, startTime, endTime, tableType, "2");
            List<Map<String, Object>> rowsSs = fetchPmRowsForUser(userName, startTime, endTime, tableType, "3");

            int totalMinutes = mergedMinutes(rows, "StartTime", "FinishTime");
            int totalMinutesRealPM = mergedMinutes(rows, "StartTime_RealPM", "FinishTime_RealPM");
            int preMinutes = mergedMinutes(rows, "StartTime", "StartTime_RealPM");
            int recoveryMinutes = mergedMinutes(rows, "FinishTime_RealPM", "FinishTime");
            int amhsMinutes = mergedMinutes(rowsAmhs, "StartTime", "FinishTime");
            int aintMinutes = mergedMinutes(rowsAint, "StartTime", "FinishTime");
            int ssMinutes = mergedMinutes(rowsSs, "StartTime", "FinishTime");

            double workLoadingReal = round2(totalMinutesRealPM * 100.0 / standardMinutes);
            double loadingAmhs = totalMinutes == 0 ? 0 : round2(amhsMinutes * 100.0 / totalMinutes);
            double loadingAint = totalMinutes == 0 ? 0 : round2(aintMinutes * 100.0 / totalMinutes);
            double loadingSs = totalMinutes == 0 ? 0 : round2(ssMinutes * 100.0 / totalMinutes);

            Map<String, Object> row = new LinkedHashMap<>();
            row.put("dep", person.get("dep"));
            row.put("userName", userName);
            row.put("totalMinutes", totalMinutes);
            row.put("totalMinutesRealPM", totalMinutesRealPM);
            row.put("preMinutes", preMinutes);
            row.put("recoveryMinutes", recoveryMinutes);
            row.put("workLoadingReal", workLoadingReal);
            row.put("loadingAmhs", loadingAmhs);
            row.put("loadingAint", loadingAint);
            row.put("loadingSs", loadingSs);
            result.add(row);
        }
        return result;
    }

    private List<Map<String, Object>> fetchPmRowsForUser(String userName, String startTime, String endTime,
                                                           String tableType, String tableDepPrefix) {
        StringBuilder sql = new StringBuilder("""
                SELECT StartTime, FinishTime, StartTime_RealPM, FinishTime_RealPM
                FROM Table_PM
                WHERE PMPeople LIKE ? AND StartTime BETWEEN ? AND ? AND Active = 1
                """);
        List<Object> args = new ArrayList<>(List.of("%" + userName + "%", startTime, endTime));

        if (tableDepPrefix != null) {
            sql.append(" AND CAST(tableDep AS CHAR) LIKE CONCAT(?, '%') ");
            args.add(tableDepPrefix);
        }
        String tt = trim(tableType);
        if (!tt.isEmpty() && !"00".equals(tt) && !"0".equals(tt)) {
            sql.append(" AND TableType = ? ");
            args.add(Integer.parseInt(tt));
        }
        return jdbc.queryForList(sql.toString(), args.toArray());
    }

    // ---------------------------------------------------------------- 部門矩陣（5-4）

    private static final int[] TABLE_TYPES = {10, 20, 30, 40, 50, 60, 70, 80, 90, 999};
    private static final String[] TABLE_TYPE_LABELS = {
            "維修組裝", "保養點檢", "教育訓練", "借機測試", "異常履勘",
            "當機扣除", "工程良率調查", "軟體更新", "值班巡檢", "其它事項"
    };

    @Override
    public List<Map<String, Object>> groupMatrix(String dep, String startTime, String endTime) {
        List<String> members = getDepMembers(dep);
        List<Map<String, Object>> result = new ArrayList<>();

        for (String name : members) {
            result.add(buildMatrixRow(name, "PMPeople LIKE ?", "%" + name + "%", startTime, endTime));
        }

        // Total 列：只要符合名單中任何一人即算入（對應原本的 OR 組合條件）
        if (!members.isEmpty()) {
            StringBuilder cond = new StringBuilder("(");
            List<Object> orArgs = new ArrayList<>();
            for (int i = 0; i < members.size(); i++) {
                cond.append(i == 0 ? "PMPeople LIKE ?" : " OR PMPeople LIKE ?");
                orArgs.add("%" + members.get(i) + "%");
            }
            cond.append(")");
            result.add(buildMatrixRowMulti("Total", cond.toString(), orArgs, startTime, endTime));
        }
        return result;
    }

    private Map<String, Object> buildMatrixRow(String userName, String cond, Object condArg,
                                                String startTime, String endTime) {
        return buildMatrixRowMulti(userName, cond, List.of(condArg), startTime, endTime);
    }

    private Map<String, Object> buildMatrixRowMulti(String label, String cond, List<Object> condArgs,
                                                      String startTime, String endTime) {
        String sql = "SELECT TableType, COUNT(*) AS cnt FROM Table_PM WHERE " + cond +
                " AND StartTime BETWEEN ? AND ? AND Active = 1 GROUP BY TableType";
        List<Object> args = new ArrayList<>(condArgs);
        args.add(startTime);
        args.add(endTime);

        List<Map<String, Object>> counts = jdbc.queryForList(sql, args.toArray());
        Map<Integer, Long> byType = new HashMap<>();
        for (Map<String, Object> c : counts) {
            Object tt = c.get("TableType");
            if (tt != null) byType.put(((Number) tt).intValue(), ((Number) c.get("cnt")).longValue());
        }

        Map<String, Object> row = new LinkedHashMap<>();
        row.put("userName", label);
        long total = 0;
        for (int i = 0; i < TABLE_TYPES.length; i++) {
            long c = byType.getOrDefault(TABLE_TYPES[i], 0L);
            row.put(TABLE_TYPE_LABELS[i], c);
            total += c;
        }
        row.put("total", total);
        return row;
    }

    @Override
    public List<String> getDepMembers(String dep) {
        return jdbc.queryForList(
                "SELECT User_Name FROM AccountTable_Active WHERE Group_4 = ? ORDER BY User_Name",
                String.class, dep);
    }

    // ---------------------------------------------------------------- 小工具

    /**
     * 區間合併演算法：排序後合併重疊/相接區間，計算聯集總分鐘數。
     * 對應原本 funcCountTime() 的逐分鐘標記法，但改用排序合併，結果相同、效能更佳。
     */
    private int mergedMinutes(List<Map<String, Object>> rows, String startCol, String endCol) {
        List<long[]> intervals = new ArrayList<>();
        for (Map<String, Object> row : rows) {
            LocalDateTime s = toLdt(row.get(startCol));
            LocalDateTime e = toLdt(row.get(endCol));
            if (s == null || e == null) continue;
            long sm = s.toEpochSecond(ZoneOffset.UTC) / 60;
            long em = e.toEpochSecond(ZoneOffset.UTC) / 60;
            if (em <= sm) continue;
            intervals.add(new long[]{sm, em});
        }
        if (intervals.isEmpty()) return 0;
        intervals.sort(Comparator.comparingLong(a -> a[0]));

        long total = 0;
        long curStart = intervals.get(0)[0];
        long curEnd = intervals.get(0)[1];
        for (int i = 1; i < intervals.size(); i++) {
            long[] iv = intervals.get(i);
            if (iv[0] <= curEnd) {
                curEnd = Math.max(curEnd, iv[1]);
            } else {
                total += (curEnd - curStart);
                curStart = iv[0];
                curEnd = iv[1];
            }
        }
        total += (curEnd - curStart);
        return (int) total;
    }

    private LocalDateTime toLdt(Object v) {
        if (v == null) return null;
        if (v instanceof LocalDateTime ldt) return ldt;
        if (v instanceof Timestamp ts) return ts.toLocalDateTime();
        return null;
    }

    private double round2(double v) {
        return Math.round(v * 100.0) / 100.0;
    }

    private String trim(String s) {
        return s == null ? "" : s.trim();
    }

    private String orDefault(String s, String def) {
        return (s == null || s.isBlank()) ? def : s;
    }
}
