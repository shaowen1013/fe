package com.shaowen.fe.service.Impl;

import com.shaowen.fe.service.MachineStatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

/**
 * MachineStatusService 的具體實作。
 * 沿用 PmServiceImpl 已確立的模式：JdbcTemplate 全參數化查詢、修改前自動寫入歷史表、
 * userId 一律來自 JWT，姓名由內部查詢取得，不信任前端傳入值。
 */
@Service
public class MachineStatusServiceImpl implements MachineStatusService {

    @Autowired
    private JdbcTemplate jdbc;

    private static final DateTimeFormatter DAY_FMT = DateTimeFormatter.ofPattern("yyyyMMdd");

    // ---------------------------------------------------------------- 下拉選單

    @Override
    public Map<String, Object> getLookups() {
        Map<String, Object> result = new HashMap<>();
        result.put("areas", jdbc.queryForList(
                "SELECT Area FROM AreaIndex WHERE sequence > -1 ORDER BY sequence", String.class));
        result.put("vendors", jdbc.queryForList(
                "SELECT DISTINCT EQ_Vendor FROM EQIndex WHERE EQ_Vendor IS NOT NULL ORDER BY EQ_Vendor", String.class));
        result.put("handoverPersons", jdbc.queryForList(
                "SELECT DISTINCT User_Name FROM AccountTable_Active WHERE User_Name IS NOT NULL ORDER BY User_Name", String.class));
        result.put("creators", jdbc.queryForList(
                "SELECT User_ID AS value, User_Name AS label FROM AccountTable_Active ORDER BY User_Name"));
        return result;
    }

    @Override
    public List<String> getEqListByArea(String area) {
        if (area == null || area.isBlank() || "-1".equals(area)) {
            return jdbc.queryForList(
                    "SELECT DISTINCT EQID FROM EQIndex WHERE EQ_Vendor IS NOT NULL ORDER BY EQID", String.class);
        }
        return jdbc.queryForList(
                "SELECT DISTINCT EQID FROM EQIndex WHERE EQ_Vendor IS NOT NULL AND EQ_Area = ? ORDER BY EQID",
                String.class, area);
    }

    // ---------------------------------------------------------------- 查詢清單

    @Override
    public Map<String, Object> search(Map<String, String> p) {
        StringBuilder where = new StringBuilder(" WHERE Table_MachineStatus.Active = 1 ");
        List<Object> args = new ArrayList<>();

        String startTime = trim(p.get("startTime"));
        String endTime = trim(p.get("endTime"));
        where.append(" AND Table_MachineStatus.StartTime BETWEEN ? AND ? ");
        args.add(startTime.isEmpty() ? "1990-01-01 00:00:00" : startTime);
        args.add(endTime.isEmpty() ? LocalDate.now().plusDays(1) + " 00:00:00" : endTime);

        String tableDep = trim(p.get("tableDep"));
        if (!tableDep.isEmpty() && !"0".equals(tableDep)) {
            // 對應原本：1->11(AMHS1), 2->12(AMHS2), 3->0(Others)
            int mapped = switch (tableDep) {
                case "1" -> 11;
                case "2" -> 12;
                case "3" -> 0;
                default -> Integer.parseInt(tableDep);
            };
            where.append(" AND Table_MachineStatus.tableDep = ? ");
            args.add(mapped);
        }

        String creatorDep = trim(p.get("creatorDep"));
        if (!creatorDep.isEmpty() && !"0".equals(creatorDep)) {
            int dep = Integer.parseInt(creatorDep);
            where.append(" AND (AccountTable_Active.Group_3 = ? OR AccountTable_Active.Group_3 = ?) ");
            args.add(dep + 1);
            args.add(dep + 2);
        }

        String alarmCode = trim(p.get("alarmCode"));
        if (!alarmCode.isEmpty()) {
            where.append(" AND Table_MachineStatus.AlarmCode LIKE ? ");
            args.add("%" + alarmCode + "%");
        }
        String cstId = trim(p.get("cstId"));
        if (!cstId.isEmpty()) {
            where.append(" AND Table_MachineStatus.CST_ID LIKE ? ");
            args.add("%" + cstId + "%");
        }
        String searchTitle = trim(p.get("searchTitle"));
        if (!searchTitle.isEmpty()) {
            where.append(" AND Table_MachineStatus.Title LIKE ? ");
            args.add("%" + searchTitle + "%");
        }
        String contextSearch = trim(p.get("contextSearch"));
        if (!contextSearch.isEmpty()) {
            where.append(" AND (Table_MachineStatus.Problem LIKE ? OR Table_MachineStatus.Resolution LIKE ?) ");
            args.add("%" + contextSearch + "%");
            args.add("%" + contextSearch + "%");
        }
        String sequence = trim(p.get("sequence"));
        if (!sequence.isEmpty()) {
            where.append(" AND Table_MachineStatus.Sequence = ? ");
            args.add(Long.parseLong(sequence));
        }
        String isFinished = trim(p.get("isFinished"));
        if (!isFinished.isEmpty() && !"-1".equals(isFinished)) {
            where.append(" AND Table_MachineStatus.isFinished = ? ");
            args.add("1".equals(isFinished));
        }
        String area = trim(p.get("area"));
        if (!area.isEmpty() && !"-1".equals(area)) {
            where.append(" AND TMP_EQIndex.EQ_Area = ? ");
            args.add(area);
        }
        String eqid = trim(p.get("eqid"));
        if (!eqid.isEmpty()) {
            where.append(" AND Table_MachineStatus.EQID = ? ");
            args.add(eqid);
        }
        String vendor = trim(p.get("vendor"));
        if (!vendor.isEmpty() && !"0".equals(vendor)) {
            where.append(" AND TMP_EQIndex.EQ_Vendor = ? ");
            args.add(vendor);
        }
        String handoverPerson = trim(p.get("handoverPerson"));
        if (!handoverPerson.isEmpty() && !"-1".equals(handoverPerson)) {
            where.append(" AND Table_MachineStatus.Handover_Person LIKE ? ");
            args.add("%" + handoverPerson + "%");
        }
        String creator = trim(p.get("creator"));
        if (!creator.isEmpty() && !"0".equals(creator)) {
            where.append(" AND Table_MachineStatus.User_ID = ? ");
            args.add(creator);
        }
        if ("true".equals(p.get("disableSomeWorks"))) {
            for (String kw : new String[]{"工事", "清潔", "量測", "Particle", "配線", "借機", "施工"}) {
                where.append(" AND Table_MachineStatus.Title NOT LIKE ? ");
                args.add("%" + kw + "%");
            }
        }
        String group4 = trim(p.get("group4"));
        if (!group4.isEmpty() && !group4.contains("AMHS")) {
            where.append(" AND TMP_EQIndex.EQ_DepType <> 'AMHS1' ");
        }

        String fromSql = """
                FROM Table_MachineStatus
                LEFT JOIN AccountTable_Active ON AccountTable_Active.User_ID = Table_MachineStatus.User_ID
                LEFT JOIN (SELECT DISTINCT EQID, EQ_Vendor, EQ_Area, EQ_DepType FROM EQIndex) AS TMP_EQIndex
                       ON Table_MachineStatus.EQID = TMP_EQIndex.EQID
                """;

        Long total = jdbc.queryForObject("SELECT COUNT(DISTINCT Table_MachineStatus.Sequence) " + fromSql + where,
                Long.class, args.toArray());

        int page = parseIntOr(p.get("page"), 0);
        int pageSize = parseIntOr(p.get("pageSize"), 20);
        boolean noPaging = "true".equals(p.get("isPage"));

        String listSql = """
                SELECT DISTINCT Table_MachineStatus.*, AccountTable_Active.User_Name AS creatorName,
                       TMP_EQIndex.EQ_Vendor AS eqVendor, TMP_EQIndex.EQ_Area AS eqArea
                """ + fromSql + where + " ORDER BY Table_MachineStatus.Sequence DESC ";

        List<Object> listArgs = new ArrayList<>(args);
        if (!noPaging) {
            listSql += " LIMIT ? OFFSET ? ";
            listArgs.add(pageSize);
            listArgs.add(page * pageSize);
        }

        List<Map<String, Object>> rows = jdbc.queryForList(listSql, listArgs.toArray());

        Map<String, Object> result = new HashMap<>();
        result.put("rows", rows);
        result.put("total", total);
        result.put("page", page);
        result.put("pageSize", pageSize);
        return result;
    }

    // ---------------------------------------------------------------- 單筆 / 歷史

    @Override
    public Map<String, Object> getOne(Long sequence) {
        List<Map<String, Object>> rows = jdbc.queryForList("""
                SELECT Table_MachineStatus.*, AccountTable_Active.User_Name AS creatorName
                FROM Table_MachineStatus
                LEFT JOIN AccountTable_Active ON AccountTable_Active.User_ID = Table_MachineStatus.User_ID
                WHERE Table_MachineStatus.Sequence = ?
                """, sequence);
        if (rows.isEmpty()) throw new NoSuchElementException("查無此機況資料：" + sequence);
        return rows.get(0);
    }

    @Override
    public List<Map<String, Object>> getHistory(Long sequence) {
        return jdbc.queryForList(
                "SELECT HistorySequence, version, ModifierName, ModifyDateTime " +
                "FROM Table_MachineStatus_History WHERE Sequence = ? ORDER BY version DESC",
                sequence);
    }

    @Override
    public Map<String, Object> getHistoryVersion(Long sequence, Integer version) {
        List<Map<String, Object>> rows = jdbc.queryForList(
                "SELECT * FROM Table_MachineStatus_History WHERE Sequence = ? AND version = ?",
                sequence, version);
        if (rows.isEmpty()) throw new NoSuchElementException("查無此歷史版本");
        return rows.get(0);
    }

    // ---------------------------------------------------------------- 新增 / 修改 / 刪除

    @Override
    @Transactional
    public Long create(String userId, Map<String, Object> body) {
        String tableSequence = userId + "_" + LocalDate.now().format(DAY_FMT);
        Integer listSequence = jdbc.queryForObject(
                "SELECT IFNULL(MAX(List_Sequence), 0) + 1 FROM Table_MachineStatus WHERE Table_Sequence = ?",
                Integer.class, tableSequence);

        String sql = """
                INSERT INTO Table_MachineStatus
                    (User_ID, Table_Sequence, InsertDate, InsertDateTime, List_Sequence, Title,
                     Area, EQID, SubEQ, StartTime, SideTime, FinishTime, AlarmCode, AlarmMessage, isFinished,
                     Caller_Person, Pricipal_Person, Handover_Person, Problem, Resolution, Scope, Active,
                     CST_ID, RealReason, DueDayTime, Action, isMO, isAR, isLack, isAdjustQuestion,
                     isTempMachineStatus, isCim, tableDep, Template)
                VALUES (?, ?, CURDATE(), NOW(), ?, ?,
                        ?, ?, ?, ?, ?, ?, ?, ?, ?,
                        ?, ?, ?, ?, ?, ?, 1,
                        ?, ?, ?, ?, ?, ?, ?, ?,
                        ?, ?, ?, ?)
                """;

        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbc.update(con -> {
            PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            int i = 1;
            ps.setString(i++, userId);
            ps.setString(i++, tableSequence);
            ps.setInt(i++, listSequence);
            ps.setString(i++, str(body, "title"));
            ps.setString(i++, str(body, "area"));
            ps.setString(i++, str(body, "eqid"));
            ps.setString(i++, str(body, "subEQ"));
            ps.setString(i++, str(body, "startTime"));
            ps.setString(i++, str(body, "sideTime"));
            ps.setString(i++, str(body, "finishTime"));
            ps.setString(i++, str(body, "alarmCode"));
            ps.setString(i++, str(body, "alarmMessage"));
            ps.setBoolean(i++, Boolean.TRUE.equals(body.get("isFinished")));
            ps.setString(i++, str(body, "callerPerson"));
            ps.setString(i++, str(body, "principalPerson"));
            ps.setString(i++, str(body, "handoverPerson"));
            ps.setString(i++, str(body, "problem"));
            ps.setString(i++, str(body, "resolution"));
            ps.setString(i++, str(body, "scope"));
            ps.setString(i++, str(body, "cstId"));
            ps.setString(i++, str(body, "realReason"));
            ps.setString(i++, str(body, "dueDayTime"));
            ps.setString(i++, str(body, "action"));
            ps.setBoolean(i++, Boolean.TRUE.equals(body.get("isMO")));
            ps.setBoolean(i++, Boolean.TRUE.equals(body.get("isAR")));
            ps.setBoolean(i++, Boolean.TRUE.equals(body.get("isLack")));
            ps.setBoolean(i++, Boolean.TRUE.equals(body.get("isAdjustQuestion")));
            ps.setBoolean(i++, Boolean.TRUE.equals(body.get("isTempMachineStatus")));
            ps.setBoolean(i++, Boolean.TRUE.equals(body.get("isCim")));
            ps.setObject(i++, body.get("tableDep"));
            ps.setBoolean(i, Boolean.TRUE.equals(body.get("template")));
            return ps;
        }, keyHolder);

        Number key = keyHolder.getKey();
        return key != null ? key.longValue() : 0L;
    }

    @Override
    @Transactional
    public void update(Long sequence, String userId, Map<String, Object> body) {
        String modifierName = resolveUserName(userId);

        // Table_MachineStatus_History 欄位 = (HistorySequence 自增) + Table_MachineStatus 所有欄位，順序相同
        jdbc.update("INSERT INTO Table_MachineStatus_History SELECT NULL, Table_MachineStatus.* " +
                "FROM Table_MachineStatus WHERE Sequence = ?", sequence);

        String sql = """
                UPDATE Table_MachineStatus SET
                    Area = ?, EQID = ?, SubEQ = ?, StartTime = ?, SideTime = ?, FinishTime = ?,
                    Caller_Person = ?, Pricipal_Person = ?, Handover_Person = ?,
                    AlarmCode = ?, AlarmMessage = ?, isFinished = ?, Problem = ?,
                    Resolution = ?, Scope = ?, CST_ID = ?, Title = ?, ModifyContext = ?,
                    RealReason = ?, DueDayTime = ?, Action = ?, isMO = ?, isAR = ?, isLack = ?,
                    isAdjustQuestion = ?, isTempMachineStatus = ?, isCim = ?, tableDep = ?, Template = ?,
                    version = version + 1, ModifierName = ?, ModifyDateTime = NOW()
                WHERE Sequence = ?
                """;
        jdbc.update(sql,
                str(body, "area"), str(body, "eqid"), str(body, "subEQ"), str(body, "startTime"),
                str(body, "sideTime"), str(body, "finishTime"),
                str(body, "callerPerson"), str(body, "principalPerson"), str(body, "handoverPerson"),
                str(body, "alarmCode"), str(body, "alarmMessage"), Boolean.TRUE.equals(body.get("isFinished")),
                str(body, "problem"), str(body, "resolution"), str(body, "scope"), str(body, "cstId"),
                str(body, "title"), str(body, "modifyContext"),
                str(body, "realReason"), str(body, "dueDayTime"), str(body, "action"),
                Boolean.TRUE.equals(body.get("isMO")), Boolean.TRUE.equals(body.get("isAR")),
                Boolean.TRUE.equals(body.get("isLack")), Boolean.TRUE.equals(body.get("isAdjustQuestion")),
                Boolean.TRUE.equals(body.get("isTempMachineStatus")), Boolean.TRUE.equals(body.get("isCim")),
                body.get("tableDep"), Boolean.TRUE.equals(body.get("template")),
                modifierName, sequence);
    }

    @Override
    @Transactional
    public void delete(Long sequence) {
        jdbc.update("UPDATE Table_MachineStatus SET Active = 0 WHERE Sequence = ?", sequence);
    }

    @Override
    public void updateFileNames(Long sequence, String fileName, String fileName2, String fileName3, String fileNameFile) {
        if (fileName != null && !fileName.isBlank())
            jdbc.update("UPDATE Table_MachineStatus SET FileName = ? WHERE Sequence = ?", fileName, sequence);
        if (fileName2 != null && !fileName2.isBlank())
            jdbc.update("UPDATE Table_MachineStatus SET FileName2 = ? WHERE Sequence = ?", fileName2, sequence);
        if (fileName3 != null && !fileName3.isBlank())
            jdbc.update("UPDATE Table_MachineStatus SET FileName3 = ? WHERE Sequence = ?", fileName3, sequence);
        if (fileNameFile != null && !fileNameFile.isBlank())
            jdbc.update("UPDATE Table_MachineStatus SET FileNameFile = ? WHERE Sequence = ?", fileNameFile, sequence);
    }

    // ---------------------------------------------------------------- 小工具

    private String resolveUserName(String userId) {
        List<String> names = jdbc.queryForList(
                "SELECT User_Name FROM AccountTable_Active WHERE User_ID = ?", String.class, userId);
        return names.isEmpty() ? userId : names.get(0);
    }

    private String str(Map<String, Object> body, String key) {
        Object v = body.get(key);
        return v != null ? v.toString() : "";
    }

    private String trim(String s) {
        return s == null ? "" : s.trim();
    }

    private int parseIntOr(String s, int def) {
        try { return Integer.parseInt(s); } catch (Exception e) { return def; }
    }
}
