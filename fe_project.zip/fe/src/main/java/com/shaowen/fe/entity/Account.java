package com.shaowen.fe.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "AccountTable")
public class Account {

    @Id
    @Column(name = "User_ID")
    private String userId;

    @Column(name = "User_Password")
    private String userPassword; // 建議改存雜湊值，見 AuthService 說明

    @Column(name = "User_Name")
    private String userName;

    @Column(name = "Job_Title")
    private String jobTitle;
    
    @Column(name = "IsIDL")
    private Boolean isIdl;
    
    @Column(name = "Group_Level")
    private int groupLevel;
    
    @Column(name = "Group_1")
    private String group1;
    
    @Column(name = "Group_2")
    private String group2;
    
    @Column(name = "Group_3")
    private String group3;
    
    @Column(name = "Email")
    private String email;
    
    @Column(name = "DefaultTableDep")
    private String defaultTableDep;
    
    @Column(name = "AccountActive")
    private Boolean accountActive;
    
    @Column(name = "Group_4")
    private String group4;
    
    @Column(name = "EquipmentOwner")
    private Boolean equipmentOwner;

    public String getUserId() { return userId; }
    public String getUserPassword() { return userPassword; }
    public String getUserName() { return userName; }
    public int getGroupLevel() { return groupLevel; }
    public String getGroup4() { return group4; }
    public String getGroup3() { return group3; }
    public String getGroup2() { return group2; }
    public String getGroup1() { return group1; }
    public String getEmail() { return email; }
    public String getDefaultTableDep() { return defaultTableDep; }
    public Boolean getEquipmentOwner() { return equipmentOwner; }
    public Boolean getIsIdl() { return isIdl; }
    public String getJobTitle() { return jobTitle; }
    public Boolean getAccountActive() { return accountActive; }
}
