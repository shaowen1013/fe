package com.shaowen.fe.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 對應原本 1.Home.aspx.cs 的三個查詢功能：
 * - 未結案之機況     (funcMachineNotFinished)
 * - 未處理之PM項目   (funcPM_NotFinished)
 * - 未結案之提案改善  (funcProposal_NotFinished)
 *
 * 原程式以字串拼接組成 SQL，此處全部改為 JdbcTemplate 參數化查詢，
 * 防止 SQL Injection。
 * 排序欄位以白名單驗證，避免 ORDER BY 注入。
 */
@RestController
@RequestMapping("/api/home")
public class HomeController {

    @Autowired
    private JdbcTemplate jdbc;

    // ── 排序欄位白名單 ──────────────────────────────────────────────────────
    private static final Set<String> MACHINE_SORT_FIELDS = Set.of(
            "sequence", "eqid", "eqVendor", "eqArea", "userName", "startTime", "handoverPerson"
    );
    private static final Set<String> PM_SORT_FIELDS = Set.of(
            "sequence", "eqid", "eqVendor", "userName", "fabPrincipal", "eqPrincipal", "statusNow"
    );
    private static final Set<String> PROPOSAL_SORT_FIELDS = Set.of(
            "sequence", "userName", "tableType", "executor", "tableStatus"
    );

    // ── 欄位名稱對應 SQL 排序欄位 ───────────────────────────────────────────
    private static final Map<String, String> MACHINE_FIELD_MAP = Map.of(
            "sequence", "Table_MachineStatus.Sequence",
            "eqid", "Table_MachineStatus.EQID",
            "eqVendor", "TMP_EQIndex.EQ_Vendor",
            "eqArea", "TMP_EQIndex.EQ_Area",
            "userName", "AccountTable_Active.User_Name",
            "startTime", "Table_MachineStatus.StartTime",
            "handoverPerson", "Table_MachineStatus.Handover_Person"
    );

    // ── 人員下拉清單 ─────────────────────────────────────────────────────────

    /**
     * 對應原本 SqlDataSource5：
     * SELECT User_Name FROM AccountTable_Active
     * WHERE Group_4 like 'AMHS%' AND AccountActive = 1
     */
    @GetMapping("/user-list")
    public ResponseEntity<List<String>> getUserList() {
        String sql = """
                SELECT User_Name FROM AccountTable_Active
                WHERE Group_4 LIKE 'AMHS%' AND AccountActive = 1
                ORDER BY User_Name
                """;
        List<String> names = jdbc.queryForList(sql, String.class);
        return ResponseEntity.ok(names);
    }

    // ── 未結案之機況 ─────────────────────────────────────────────────────────

    /**
     * 對應 funcMachineNotFinished。
     * 原程式以 '%' + SearchUserName + '%' 字串拼接，改為 ? 參數化。
     */
    @GetMapping("/machine-not-finished")
    public ResponseEntity<List<Map<String, Object>>> getMachineNotFinished(
            @RequestParam(defaultValue = "") String userName,
            @RequestParam(defaultValue = "") String sortField,
            @RequestParam(defaultValue = "ASC") String sortDir) {

        String orderBy = buildOrderBy(sortField, sortDir, MACHINE_SORT_FIELDS,
                MACHINE_FIELD_MAP, "Table_MachineStatus.Sequence DESC");

        String sql = """
                SELECT DISTINCT
                    Table_MachineStatus.Sequence        AS sequence,
                    Table_MachineStatus.EQID            AS eqid,
                    TMP_EQIndex.EQ_Vendor               AS eqVendor,
                    TMP_EQIndex.EQ_Area                 AS eqArea,
                    AccountTable_Active.User_Name       AS userName,
                    Table_MachineStatus.StartTime       AS startTime,
                    Table_MachineStatus.Handover_Person AS handoverPerson
                FROM Table_MachineStatus
                LEFT JOIN AccountTable_Active
                    ON AccountTable_Active.User_ID = Table_MachineStatus.User_ID
                LEFT JOIN (
                    SELECT DISTINCT EQID, EQ_Vendor, EQ_Area FROM EQIndex
                ) AS TMP_EQIndex
                    ON Table_MachineStatus.EQID = TMP_EQIndex.EQID
                WHERE (
                    Table_MachineStatus.Handover_Person LIKE ?
                    OR AccountTable_Active.User_Name = ?
                )
                AND Active = 1
                AND isFinished = 0
                AND AccountTable_Active.AccountActive = 1
                """ + orderBy;

        String likeParam = "%" + userName + "%";
        List<Map<String, Object>> result = jdbc.queryForList(sql, likeParam, userName);
        return ResponseEntity.ok(result);
    }

    // ── 未處理之PM項目 ───────────────────────────────────────────────────────

    @GetMapping("/pm-not-finished")
    public ResponseEntity<List<Map<String, Object>>> getPMNotFinished(
            @RequestParam(defaultValue = "") String userName,
            @RequestParam(defaultValue = "") String sortField,
            @RequestParam(defaultValue = "ASC") String sortDir) {

        String defaultOrder = "Table_PM.Sequence DESC";
        String orderBy = buildOrderBy(sortField, sortDir, PM_SORT_FIELDS, Map.of(), defaultOrder);

        String sql = """
                SELECT
                    Table_PM.Sequence                   AS sequence,
                    Table_PM.EQID                       AS eqid,
                    TMP_EQIndex.EQ_Vendor               AS eqVendor,
                    AccountTable_Active.User_Name       AS userName,
                    Table_PM.FabPrincipal               AS fabPrincipal,
                    Table_PM.EQPrincipal                AS eqPrincipal,
                    Table_Status.StatusNow_Sequence     AS statusNow
                FROM Table_PM
                LEFT JOIN AccountTable_Active
                    ON AccountTable_Active.User_ID = Table_PM.User_ID
                LEFT JOIN Table_Status
                    ON Table_Status.StatusNow_Sequence = Table_PM.StatusNow
                LEFT JOIN (
                    SELECT DISTINCT EQID, EQ_Vendor FROM EQIndex
                ) AS TMP_EQIndex
                    ON Table_PM.EQID = TMP_EQIndex.EQID
                LEFT JOIN Table_PM_TableType
                    ON Table_PM.TableType = Table_PM_TableType.TableType_Sequence
                WHERE Active = '1'
                AND isErr = 'True'
                AND isErrClear = 'False'
                AND (
                    FabPrincipal LIKE ?
                    OR EQPrincipal LIKE ?
                    OR AccountTable_Active.User_Name = ?
                )
                AND AccountTable_Active.AccountActive = 1
                """ + orderBy;

        String likeParam = "%" + userName + "%";
        List<Map<String, Object>> result = jdbc.queryForList(sql, likeParam, likeParam, userName);
        return ResponseEntity.ok(result);
    }

    // ── 未結案之提案改善項目 ─────────────────────────────────────────────────

    @GetMapping("/proposal-not-finished")
    public ResponseEntity<List<Map<String, Object>>> getProposalNotFinished(
            @RequestParam(defaultValue = "") String userName,
            @RequestParam(defaultValue = "") String sortField,
            @RequestParam(defaultValue = "ASC") String sortDir) {

        String defaultOrder = "Table_Proposal.Sequence DESC";
        String orderBy = buildOrderBy(sortField, sortDir, PROPOSAL_SORT_FIELDS, Map.of(), defaultOrder);

        String sql = """
                SELECT
                    Table_Proposal.Sequence                         AS sequence,
                    AccountTable_Active.User_Name                   AS userName,
                    Table_Proposal_TableType.TableType_Sequence     AS tableType,
                    Table_Proposal.Executor                         AS executor,
                    Table_Proposal_TableStatus.TableStatus          AS tableStatus
                FROM Table_Proposal
                LEFT JOIN AccountTable_Active
                    ON AccountTable_Active.User_ID = Table_Proposal.User_ID
                LEFT JOIN Table_Proposal_TableStatus
                    ON Table_Proposal_TableStatus.TableStatus = Table_Proposal.TableStatus
                LEFT JOIN Table_Proposal_TableType
                    ON Table_Proposal_TableType.TableType_Sequence = Table_Proposal.TableType
                WHERE Active = '1'
                AND Executor = ?
                AND TableStatus_Sequence != 6
                AND AccountTable_Active.AccountActive = 1
                """ + orderBy;

        List<Map<String, Object>> result = jdbc.queryForList(sql, userName);
        return ResponseEntity.ok(result);
    }

    // ── 工具方法：安全的 ORDER BY 組裝（白名單驗證）────────────────────────

    private String buildOrderBy(String sortField, String sortDir,
                                 Set<String> allowedFields,
                                 Map<String, String> fieldMap,
                                 String defaultOrder) {
        String safeDir = "DESC".equalsIgnoreCase(sortDir) ? "DESC" : "ASC";

        if (sortField == null || sortField.isBlank() || !allowedFields.contains(sortField)) {
            return " ORDER BY " + defaultOrder;
        }

        String sqlField = fieldMap.getOrDefault(sortField, sortField);
        return " ORDER BY " + sqlField + " " + safeDir;
    }
}
