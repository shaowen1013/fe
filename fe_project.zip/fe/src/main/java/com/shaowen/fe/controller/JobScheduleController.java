package com.shaowen.fe.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.web.bind.annotation.*;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import java.util.Map;

/**
 * 對應 8-2.JobSchedule.aspx.cs 的 CRUD 邏輯：
 * - GET    /api/job-schedule/{seq}   → Initial_Job（查詢單筆）
 * - POST   /api/job-schedule         → funcSave 新增
 * - PUT    /api/job-schedule/{seq}   → funcSave 修改
 * - DELETE /api/job-schedule/{seq}   → btnDelete_Click（Active=0）
 * - POST   /api/job-schedule/extend  → btnExtend_Click（遞延並更新 ExtendSequence）
 */
@RestController
@RequestMapping("/api/job-schedule")
public class JobScheduleController {

    @Autowired
    private JdbcTemplate jdbc;

    /** 查詢單筆（對應 Initial_Job） */
    @GetMapping("/{sequence}")
    public ResponseEntity<Map<String, Object>> getJob(@PathVariable Long sequence) {
        String sql = """
                SELECT J.*,
                       DATE_FORMAT(StartTime, '%Y/%m/%d') AS startTime,
                       DATE_FORMAT(StartTime, '%H:%i') AS endTime,
                       A.User_Name AS userName
                FROM Table_JobSchedule J
                LEFT JOIN AccountTable_Active A ON A.User_ID = J.User_ID
                WHERE J.Sequence = ?
                """;
        List<Map<String, Object>> rows = jdbc.queryForList(sql, sequence);
        if (rows.isEmpty()) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(rows.get(0));
    }

    /** 新增（對應 btnSave_Click → funcSave 新增分支） */
    @PostMapping
    public ResponseEntity<Map<String, Object>> createJob(@RequestBody Map<String, Object> body) {
        String sql = """
                INSERT INTO Table_JobSchedule
                    (User_ID, tableDep, Area, EQID, SubEQ,
                     StartTime, EndTime, WorkInfo, Period,
                     StopEQReason, Priority, Prearranged_Person,
                     isNeedLend, LendStatus, Active)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
                """;

        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbc.update(con -> {
            PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, str(body, "userId"));
            ps.setString(2, str(body, "tableDep"));
            ps.setString(3, str(body, "area"));
            ps.setString(4, str(body, "eqid"));
            ps.setString(5, str(body, "subEQ"));
            ps.setString(6, str(body, "startTime"));
            ps.setString(7, str(body, "endTime"));
            ps.setString(8, str(body, "workInfo"));
            ps.setString(9, str(body, "period"));
            ps.setString(10, str(body, "stopEQReason"));
            ps.setString(11, str(body, "priority"));
            ps.setString(12, str(body, "prearrangedPerson"));
            ps.setBoolean(13, Boolean.TRUE.equals(body.get("isNeedLend")));
            Object lend = body.get("lendStatus");
            if (lend == null || !Boolean.TRUE.equals(body.get("isNeedLend")))
                ps.setNull(14, java.sql.Types.INTEGER);
            else ps.setString(14, lend.toString());
            return ps;
        }, keyHolder);

        Number newKey = keyHolder.getKey();
        return ResponseEntity.ok(Map.of("sequence", newKey != null ? newKey.longValue() : 0));
    }

    /** 修改（對應 btnSave_Click → funcSave 修改分支） */
    @PutMapping("/{sequence}")
    public ResponseEntity<Void> updateJob(@PathVariable Long sequence,
                                          @RequestBody Map<String, Object> body) {
        String sql = """
                UPDATE Table_JobSchedule SET
                    tableDep = ?, Area = ?, EQID = ?, SubEQ = ?,
                    StartTime = ?, EndTime = ?, WorkInfo = ?, Period = ?,
                    StopEQReason = ?, Priority = ?, Prearranged_Person = ?,
                    isNeedLend = ?, LendStatus = ?
                WHERE Sequence = ?
                """;
        jdbc.update(sql,
                str(body, "tableDep"), str(body, "area"), str(body, "eqid"), str(body, "subEQ"),
                str(body, "startTime"), str(body, "endTime"), str(body, "workInfo"), str(body, "period"),
                str(body, "stopEQReason"), str(body, "priority"), str(body, "prearrangedPerson"),
                Boolean.TRUE.equals(body.get("isNeedLend")),
                Boolean.TRUE.equals(body.get("isNeedLend")) ? str(body, "lendStatus") : null,
                sequence);
        return ResponseEntity.ok().build();
    }

    /** 軟刪除（Active=0，對應 btnDelete_Click） */
    @DeleteMapping("/{sequence}")
    public ResponseEntity<Void> deleteJob(@PathVariable Long sequence) {
        jdbc.update("UPDATE Table_JobSchedule SET Active = 0 WHERE Sequence = ?", sequence);
        return ResponseEntity.ok().build();
    }

    /**
     * 遞延（對應 btnExtend_Click）：
     * 新增一筆，再把舊筆的 ExtendSequence 更新為新筆的 Sequence。
     */
    @PostMapping("/extend")
    public ResponseEntity<Map<String, Object>> extendJob(@RequestBody Map<String, Object> body) {
        // 先新增一筆（同 create 邏輯）
        ResponseEntity<Map<String, Object>> createResult = createJob(body);
        Object newSeq = createResult.getBody() != null ? createResult.getBody().get("sequence") : null;

        if (newSeq != null) {
            Object originalSeq = body.get("originalSequence");
            jdbc.update(
                "UPDATE Table_JobSchedule SET ExtendSequence = ? WHERE Sequence = ?",
                newSeq, originalSeq);
        }
        return ResponseEntity.ok(Map.of("sequence", newSeq != null ? newSeq : 0));
    }

    private String str(Map<String, Object> body, String key) {
        Object v = body.get(key);
        return v != null ? v.toString() : "";
    }
}
