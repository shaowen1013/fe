package com.shaowen.fe.service;

import java.util.List;
import java.util.Map;

/**
 * PM 保養模組服務介面。
 * 對應 5-1.PM_System_Search.aspx.cs（查詢）與 5-2.PM_System_Act.aspx.cs（新增/修改/歷史）。
 */
public interface PmService {

    /**
     * 下拉選單/篩選用清單（一次回傳，減少前端來回呼叫次數）：
     * areas, tableTypes, statusNowList, vendors, eqPrincipals, fabPrincipals, deps
     */
    Map<String, Object> getLookups();

    /** 依廠別查詢設備清單（僅列出 EQ_Vendor 不為空者，對應 initialDrpEQ / drpListEQ） */
    List<String> getEqListByArea(String area);

    /**
     * 查詢清單（對應 reflash_GridView1）。
     * params 可包含：tableDep, area, eqid, riskLevel, sequence, vendor, tableType,
     * dep, statusNow, isErr, isErrClear, startTime, endTime, keyword, page, pageSize, isPage, group4
     */
    Map<String, Object> search(Map<String, String> params);

    /** 查詢單筆現行資料（對應 Initial_PM，TableName = Table_PM） */
    Map<String, Object> getOne(Long sequence);

    /** 查詢歷史版本清單（對應 History 查詢，TableName = Table_PM_History） */
    List<Map<String, Object>> getHistory(Long sequence);

    /** 查詢單一歷史版本內容 */
    Map<String, Object> getHistoryVersion(Long sequence, Integer version);

    /**
     * 新增（對應 btnNew_Click 的 else 分支）。
     * userId 來自 JWT 驗證身分；填表人姓名由內部查 AccountTable_Active 取得，不信任前端輸入。
     */
    Long create(String userId, Map<String, Object> body);

    /**
     * 修改（對應 btnNew_Click 的 Actions=m 分支）：
     * 1. 先把目前 Table_PM 該筆複製一份到 Table_PM_History
     * 2. 再以新內容 UPDATE Table_PM，version+1，寫入 ModifierName / ModifyDateTime
     * 需使用 @Transactional 確保兩步驟一致。userId 來自 JWT，姓名由內部查詢取得。
     */
    void update(Long sequence, String userId, Map<String, Object> body);

    /**
     * 軟刪除（對應 GridView1_RowDeleting）：
     * Table_PM.Active = 0，並清除關聯的 Table_JobSchedule.PMTableSequence。
     */
    void delete(Long sequence);

    /** 更新檔案欄位（圖片1 / 圖片2 / 附件），對應 FileUploadPicture / FileUpload 後的三段 UPDATE */
    void updateFileNames(Long sequence, String fileName, String fileName2, String fileNameFile);
}
