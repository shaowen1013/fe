package com.shaowen.fe.controller;

import com.shaowen.fe.service.PmWorkTimeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 對應 5-3.PM_PersonWorkTime_Search.aspx（個人／全體工時查詢）
 * 與 5-4.PM_PersonWorkTime_ByGroup.aspx（依部門統計表單類型次數矩陣）。
 */
@RestController
@RequestMapping("/api/pm-worktime")
public class PmWorkTimeController {

    @Autowired
    private PmWorkTimeService workTimeService;

    /** 個人模式查詢（對應 RadioButtonList1=1） */
    @GetMapping("/personal")
    public ResponseEntity<Map<String, Object>> personal(@RequestParam Map<String, String> params) {
        return ResponseEntity.ok(workTimeService.searchPersonal(params));
    }

    /**
     * 全體模式查詢（對應 RadioButtonList1=0）。
     * 會對每位人員各執行數次區間合併查詢，人數多時回應較慢，前端應顯示載入中提示。
     */
    @GetMapping("/all")
    public ResponseEntity<List<Map<String, Object>>> all(@RequestParam Map<String, String> params) {
        return ResponseEntity.ok(workTimeService.searchAll(params));
    }

    /** 依部門統計各表單型態次數矩陣（對應 5-4） */
    @GetMapping("/group-matrix")
    public ResponseEntity<List<Map<String, Object>>> groupMatrix(
            @RequestParam String dep,
            @RequestParam String startTime,
            @RequestParam String endTime) {
        return ResponseEntity.ok(workTimeService.groupMatrix(dep, startTime, endTime));
    }

    /** 依部門代碼取得人員名單（供前端「整組」篩選與 5-4 使用） */
    @GetMapping("/dep-members")
    public ResponseEntity<List<String>> depMembers(@RequestParam String dep) {
        return ResponseEntity.ok(workTimeService.getDepMembers(dep));
    }
}
