package com.shaowen.fe.service.Impl;

import com.shaowen.fe.service.PmService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

/**
 * PmService 的具體實作。
 *
 * 遷移重點（相較原本 5-1 / 5-2 頁面）：
 * - 所有查詢條件一律以 PreparedStatement 參數化，取代原本用字串拼接組 SQL 的寫法，
 *   杜絕 SQL Injection。
 * - MySQL 語法差異：CONVERT(...,111/120) 改用 DATE_FORMAT；ISNULL 改用 IFNULL。
 * - List_Sequence（每人每日流水號）改由後端依 Table_Sequence 動態查詢 MAX+1 產生，
 *   不再信任前端傳入值。
 */
@Service
public class PmServiceImpl implements PmService {

    @Autowired
    private JdbcTemplate jdbc;

    private static final DateTimeFormatter DAY_FMT = DateTimeFormatter.ofPattern("yyyyMMdd");

    // ---------------------------------------------------------------- 下拉選單

    @Override
    public Map<String, Object> getLookups() {
        Map<String, Object> result = new HashMap<>();
        result.put("areas", jdbc.queryForList(
                "SELECT Area FROM AreaIndex WHERE sequence > -1 ORDER BY sequence", String.class));
        result.put("tableTypes", jdbc.queryForList(
                "SELECT TableType_Sequence AS value, TableType_Chinese AS label FROM Table_PM_TableType ORDER BY TableType_Sequence"));
        result.put("statusNowList", jdbc.queryForList(
                "SELECT StatusNow_Sequence AS value, StatusNow_Chinese AS label FROM Table_PM_StatusNow ORDER BY StatusNow_Sequence"));
        result.put("vendors", jdbc.queryForList(
                "SELECT DISTINCT EQ_Vendor FROM EQIndex WHERE EQ_Vendor IS NOT NULL ORDER BY EQ_Vendor", String.class));
        result.put("fabPrincipals", jdbc.queryForList(
                "SELECT DISTINCT User_Name FROM AccountTable_Active WHERE User_Name IS NOT NULL ORDER BY User_Name", String.class));
        result.put("eqPrincipals", jdbc.queryForList(
                "SELECT DISTINCT EQPrincipal FROM Table_PM WHERE EQPrincipal IS NOT NULL AND EQPrincipal <> '' ORDER BY EQPrincipal", String.class));
        return result;
    }

    @Override
    public List<String> getEqListByArea(String area) {
        if (area == null || area.isBlank() || "0".equals(area)) {
            return jdbc.queryForList(
                    "SELECT DISTINCT EQID FROM EQIndex WHERE EQ_Vendor IS NOT NULL ORDER BY EQID", String.class);
        }
        return jdbc.queryForList(
                "SELECT DISTINCT EQID FROM EQIndex WHERE EQ_Vendor IS NOT NULL AND Area = ? ORDER BY EQID",
                String.class, area);
    }

    // ---------------------------------------------------------------- 查詢清單

    @Override
    public Map<String, Object> search(Map<String, String> p) {
        StringBuilder where = new StringBuilder(" WHERE Table_PM.Active = 1 ");
        List<Object> args = new ArrayList<>();

        String keyword = trimToEmpty(p.get("keyword"));
        if (!keyword.isEmpty()) {
            where.append(""" 
                    AND (Table_PM.Area LIKE ? OR Table_PM.EQID LIKE ? OR Table_PM.SubEQ LIKE ?
                         OR Table_PM.RentEQTime LIKE ? OR Table_PM.PMPeople LIKE ? OR Table_PM.EQPrincipal LIKE ?
                         OR Table_PM.Vendor LIKE ? OR Table_PM.Problem LIKE ? OR Table_PM.Remark LIKE ?
                         OR Table_PM.StopEQReason LIKE ? OR Table_PM.FileNameFile LIKE ?)
                    """);
            String kw = "%" + keyword + "%";
            for (int i = 0; i < 11; i++) args.add(kw);
        }

        // 表單歸屬（0=AMHS1, 1=AMHS2, 2=其他... 對應原本 rblTableDep）
        // 表單歸屬：畫面用簡化代碼(0=ALL/1=AMHS1/2=AMHS2)，資料庫實際存放 DepIndex.DEP_NO 代碼(11/12)，
        // 轉換規則對應原系統 MyModule1.funcTableDep()。
        String tableDep = trimToEmpty(p.get("tableDep"));
        String mappedTableDep = mapDep(tableDep);
        if (mappedTableDep != null) {
            where.append(" AND Table_PM.tableDep = ? ");
            args.add(mappedTableDep);
        }

        String startTime = trimToEmpty(p.get("startTime"));
        String endTime = trimToEmpty(p.get("endTime"));
        where.append(" AND Table_PM.StartTime BETWEEN ? AND ? ");
        args.add(startTime.isEmpty() ? "1990-01-01 00:00:00" : startTime);
        args.add(endTime.isEmpty() ? LocalDate.now().plusDays(1) + " 00:00:00" : endTime);

        String isErr = p.get("isErr");
        if ("1".equals(isErr) || "0".equals(isErr)) {
            where.append(" AND Table_PM.isErr = ? ");
            args.add("1".equals(isErr));
        }
        String isErrClear = p.get("isErrClear");
        if ("1".equals(isErrClear) || "0".equals(isErrClear)) {
            where.append(" AND Table_PM.isErrClear = ? ");
            args.add("1".equals(isErrClear));
        }
        String statusNow = trimToEmpty(p.get("statusNow"));
        if (!statusNow.isEmpty() && Integer.parseInt(statusNow) > -1) {
            where.append(" AND Table_PM.StatusNow = ? ");
            args.add(Integer.parseInt(statusNow));
        }
        String area = trimToEmpty(p.get("area"));
        if (!area.isEmpty() && !"0".equals(area)) {
            where.append(" AND Table_PM.Area = ? ");
            args.add(area);
        }
        String eqid = trimToEmpty(p.get("eqid"));
        if (!eqid.isEmpty()) {
            where.append(" AND Table_PM.EQID = ? ");
            args.add(eqid);
        }
        String riskLevel = trimToEmpty(p.get("riskLevel"));
        if (!riskLevel.isEmpty()) {
            where.append(" AND Table_PM.RiskLevel = ? ");
            args.add(Integer.parseInt(riskLevel));
        }
        String sequence = trimToEmpty(p.get("sequence"));
        if (!sequence.isEmpty()) {
            where.append(" AND Table_PM.Sequence = ? ");
            args.add(Long.parseLong(sequence));
        }
        String vendor = trimToEmpty(p.get("vendor"));
        if (!vendor.isEmpty() && !"0".equals(vendor)) {
            where.append(" AND TMP_EQIndex.EQ_Vendor = ? ");
            args.add(vendor);
        }
        String tableType = trimToEmpty(p.get("tableType"));
        if (!tableType.isEmpty() && !"0".equals(tableType)) {
            where.append(" AND Table_PM.TableType = ? ");
            args.add(Integer.parseInt(tableType));
        }
        // 非 AMHS 人員不可查 AMHS1 設備（對應 strSentence_RejectNotFASearch）
        String group4 = trimToEmpty(p.get("group4"));
        if (!group4.isEmpty() && !group4.contains("AMHS")) {
            where.append(" AND TMP_EQIndex.EQ_DepType <> 'AMHS1' ");
        }

        String fromSql = """
                FROM Table_PM
                LEFT JOIN AccountTable_Active ON AccountTable_Active.User_ID = Table_PM.User_ID
                LEFT JOIN Table_PM_StatusNow ON Table_PM_StatusNow.StatusNow_Sequence = Table_PM.StatusNow
                LEFT JOIN (SELECT DISTINCT EQID, EQ_Vendor, EQ_DepType FROM EQIndex) AS TMP_EQIndex
                       ON Table_PM.EQID = TMP_EQIndex.EQID
                LEFT JOIN Table_PM_TableType ON Table_PM.TableType = Table_PM_TableType.TableType_Sequence
                """;

        Long total = jdbc.queryForObject(
                "SELECT COUNT(*) " + fromSql + where, Long.class, args.toArray());

        int page = parseIntOr(p.get("page"), 0);
        int pageSize = parseIntOr(p.get("pageSize"), 20);
        boolean noPaging = "true".equals(p.get("isPage"));

        String listSql = """
                SELECT Table_PM.*, AccountTable_Active.User_Name AS creatorName,
                       Table_PM_StatusNow.StatusNow_Chinese AS statusNowText,
                       Table_PM_TableType.TableType_Chinese AS tableTypeText,
                       TMP_EQIndex.EQ_Vendor AS eqVendor
                """ + fromSql + where + " ORDER BY Table_PM.Sequence DESC ";

        List<Object> listArgs = new ArrayList<>(args);
        if (!noPaging) {
            listSql += " LIMIT ? OFFSET ? ";
            listArgs.add(pageSize);
            listArgs.add(page * pageSize);
        }

        List<Map<String, Object>> rows = jdbc.queryForList(listSql, listArgs.toArray());

        Map<String, Object> result = new HashMap<>();
        result.put("rows", rows);
        result.put("total", total);
        result.put("page", page);
        result.put("pageSize", pageSize);
        return result;
    }

    // ---------------------------------------------------------------- 單筆 / 歷史

    @Override
    public Map<String, Object> getOne(Long sequence) {
        String sql = """
                SELECT Table_PM.*, AccountTable_Active.User_Name AS creatorName
                FROM Table_PM
                LEFT JOIN AccountTable_Active ON AccountTable_Active.User_ID = Table_PM.User_ID
                WHERE Table_PM.Sequence = ?
                """;
        List<Map<String, Object>> rows = jdbc.queryForList(sql, sequence);
        if (rows.isEmpty()) throw new NoSuchElementException("查無此 PM 資料：" + sequence);
        return rows.get(0);
    }

    @Override
    public List<Map<String, Object>> getHistory(Long sequence) {
        return jdbc.queryForList(
                "SELECT HistorySequence, version, ModifierName, ModifyDateTime " +
                "FROM Table_PM_History WHERE Sequence = ? ORDER BY version DESC",
                sequence);
    }

    @Override
    public Map<String, Object> getHistoryVersion(Long sequence, Integer version) {
        List<Map<String, Object>> rows = jdbc.queryForList(
                "SELECT * FROM Table_PM_History WHERE Sequence = ? AND version = ?",
                sequence, version);
        if (rows.isEmpty()) throw new NoSuchElementException("查無此歷史版本");
        return rows.get(0);
    }

    // ---------------------------------------------------------------- 新增 / 修改 / 刪除

    @Override
    @Transactional
    public Long create(String userId, Map<String, Object> body) {
        String tableSequence = userId + "_" + LocalDate.now().format(DAY_FMT);

        Integer listSequence = jdbc.queryForObject(
                "SELECT IFNULL(MAX(List_Sequence), 0) + 1 FROM Table_PM WHERE Table_Sequence = ?",
                Integer.class, tableSequence);

        String sql = """
                INSERT INTO Table_PM
                    (User_ID, Table_Sequence, InsertDate, InsertDateTime, List_Sequence, TableType,
                     Area, EQID, SubEQ, RentEQTime, StartTime, FinishTime, StartTime_RealPM, FinishTime_RealPM,
                     PMPeople, PMPeople_Support, EQPrincipal, FabPrincipal, Vendor, Problem, Remark, StopEQReason,
                     PredictPMDateTime, StatusNow, Active, tableDep, isErr, isErrClear, RiskLevel, dateErrClear)
                VALUES (?, ?, CURDATE(), NOW(), ?, ?,
                        ?, ?, ?, ?, ?, ?, ?, ?,
                        ?, ?, ?, ?, ?, ?, ?, ?,
                        ?, ?, 1, ?, ?, ?, ?, ?)
                """;

        boolean isErr = Boolean.TRUE.equals(body.get("isErr"));
        boolean isErrClear = Boolean.TRUE.equals(body.get("isErrClear"));

        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbc.update(con -> {
            PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            int i = 1;
            ps.setString(i++, userId);
            ps.setString(i++, tableSequence);
            ps.setInt(i++, listSequence);
            ps.setObject(i++, body.get("tableType"));
            ps.setString(i++, str(body, "area"));
            ps.setString(i++, str(body, "eqid"));
            ps.setString(i++, str(body, "subEQ"));
            ps.setString(i++, str(body, "rentEQTime"));
            ps.setString(i++, str(body, "startTime"));
            ps.setString(i++, str(body, "finishTime"));
            ps.setString(i++, str(body, "startTimeRealPM"));
            ps.setString(i++, str(body, "finishTimeRealPM"));
            ps.setString(i++, str(body, "pmPeople"));
            ps.setString(i++, str(body, "pmPeopleSupport"));
            ps.setString(i++, str(body, "eqPrincipal"));
            ps.setString(i++, str(body, "fabPrincipal"));
            ps.setString(i++, str(body, "vendor"));
            ps.setString(i++, str(body, "problem"));
            ps.setString(i++, str(body, "remark"));
            ps.setString(i++, str(body, "stopEQReason"));
            ps.setString(i++, str(body, "predictPMDateTime"));
            ps.setObject(i++, body.get("statusNow"));
            ps.setString(i++, str(body, "tableDep"));
            ps.setBoolean(i++, isErr);
            ps.setBoolean(i++, isErrClear);
            if (isErr) ps.setObject(i++, body.get("riskLevel"));
            else ps.setNull(i++, java.sql.Types.INTEGER);
            ps.setString(i, str(body, "dateErrClear"));
            return ps;
        }, keyHolder);

        Number key = keyHolder.getKey();
        return key != null ? key.longValue() : 0L;
    }

    @Override
    @Transactional
    public void update(Long sequence, String userId, Map<String, Object> body) {
        String modifierName = resolveUserName(userId);

        // 1) 先把現行資料複製一份到 Table_PM_History（保留修改前的版本）
        // Table_PM_History 的欄位 = (HistorySequence 自增) + Table_PM 的所有欄位，且順序完全相同，
        // 因此可直接用 NULL + Table_PM.* 對應寫入，不需逐欄位列舉。
        jdbc.update("INSERT INTO Table_PM_History SELECT NULL, Table_PM.* FROM Table_PM WHERE Sequence = ?", sequence);

        boolean isErr = Boolean.TRUE.equals(body.get("isErr"));
        boolean isErrClear = Boolean.TRUE.equals(body.get("isErrClear"));

        String sql = """
                UPDATE Table_PM SET
                    TableType = ?, Area = ?, EQID = ?, SubEQ = ?, RentEQTime = ?,
                    StartTime = ?, FinishTime = ?, StartTime_RealPM = ?, FinishTime_RealPM = ?,
                    PMPeople = ?, PMPeople_Support = ?, EQPrincipal = ?, FabPrincipal = ?, Vendor = ?,
                    Problem = ?, Remark = ?, StopEQReason = ?, PredictPMDateTime = ?, StatusNow = ?,
                    tableDep = ?, isErr = ?, isErrClear = ?, RiskLevel = ?, dateErrClear = ?,
                    version = version + 1, ModifierName = ?, ModifyDateTime = NOW()
                WHERE Sequence = ?
                """;
        jdbc.update(sql,
                body.get("tableType"), str(body, "area"), str(body, "eqid"), str(body, "subEQ"), str(body, "rentEQTime"),
                str(body, "startTime"), str(body, "finishTime"), str(body, "startTimeRealPM"), str(body, "finishTimeRealPM"),
                str(body, "pmPeople"), str(body, "pmPeopleSupport"), str(body, "eqPrincipal"), str(body, "fabPrincipal"), str(body, "vendor"),
                str(body, "problem"), str(body, "remark"), str(body, "stopEQReason"), str(body, "predictPMDateTime"), body.get("statusNow"),
                str(body, "tableDep"), isErr, isErrClear, isErr ? body.get("riskLevel") : null, str(body, "dateErrClear"),
                modifierName, sequence);
    }

    @Override
    @Transactional
    public void delete(Long sequence) {
        jdbc.update("UPDATE Table_PM SET Active = 0 WHERE Sequence = ?", sequence);
        jdbc.update("UPDATE Table_JobSchedule SET PMTableSequence = NULL, PMTableSequenceHist = ? " +
                "WHERE PMTableSequence = ?", sequence, sequence);
    }

    @Override
    public void updateFileNames(Long sequence, String fileName, String fileName2, String fileNameFile) {
        if (fileName != null && !fileName.isBlank())
            jdbc.update("UPDATE Table_PM SET FileName = ? WHERE Sequence = ?", fileName, sequence);
        if (fileName2 != null && !fileName2.isBlank())
            jdbc.update("UPDATE Table_PM SET FileName2 = ? WHERE Sequence = ?", fileName2, sequence);
        if (fileNameFile != null && !fileNameFile.isBlank())
            jdbc.update("UPDATE Table_PM SET FileNameFile = ? WHERE Sequence = ?", fileNameFile, sequence);
    }

    // ---------------------------------------------------------------- 小工具

    private String str(Map<String, Object> body, String key) {
        Object v = body.get(key);
        return v != null ? v.toString() : "";
    }

    private String trimToEmpty(String s) {
        return s == null ? "" : s.trim();
    }

    /** 對應 MyModule1.funcTableDep()：1→'11'(AMHS1), 2→'12'(AMHS2), 0/其他→不篩選(null)。 */
    private String mapDep(String dep) {
        if (dep == null) return null;
        return switch (dep.trim()) {
            case "1" -> "11";
            case "2" -> "12";
            default -> null;
        };
    }

    private int parseIntOr(String s, int def) {
        try { return Integer.parseInt(s); } catch (Exception e) { return def; }
    }

    /** 依 JWT 內的 userId 查詢顯示用姓名，避免信任前端傳入的姓名欄位。 */
    private String resolveUserName(String userId) {
        List<String> names = jdbc.queryForList(
                "SELECT User_Name FROM AccountTable_Active WHERE User_ID = ?", String.class, userId);
        return names.isEmpty() ? userId : names.get(0);
    }
}
