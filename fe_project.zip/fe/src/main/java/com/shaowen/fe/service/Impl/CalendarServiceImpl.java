package com.shaowen.fe.service.Impl;

import com.shaowen.fe.service.CalendarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * CalendarService 的具體實作。
 *
 * 這裡修正了先前版本的兩個問題：
 * 1. tableDep 代碼轉換錯誤：畫面上的簡化代碼（1=AMHS1, 2=AMHS2）先前被直接拿去比對
 *    tableDep 欄位，但資料庫實際存放的是 DepIndex.DEP_NO 代碼（11, 12...），
 *    導致依「表單歸屬」篩選 AMHS1/AMHS2 時查不到任何資料。現在改用與原系統
 *    MyModule1.funcTableDep() 相同的轉換規則（1→11, 2→12）。
 * 2. 「臨時工作」先前錯誤地查詢 Table_MachineStatus（機況表），且用了 MySQL 不支援的
 *    ISNULL(x,y) 兩參數語法。實際上原系統的「臨時工作」跟「預排工作」同樣來自
 *    Table_JobSchedule，只是用 Period='0' 區分（對應原本 funcPre 的 isPreWork/isTempWork
 *    參數），現在已修正為與 Table_JobSchedule 一致的查詢方式。
 */
@Service
public class CalendarServiceImpl implements CalendarService {

    @Autowired
    private JdbcTemplate jdbc;

    @Override
    public List<String> getAreas() {
        return jdbc.queryForList(
                "SELECT Area FROM AreaIndex WHERE sequence > -1 ORDER BY sequence", String.class);
    }

    @Override
    public List<String> getEqList(String area, String dep) {
        String mappedDep = mapDep(dep);
        if (mappedDep == null) {
            return jdbc.queryForList(
                    "SELECT DISTINCT EQID FROM EQIndex WHERE Area = ? ORDER BY EQID", String.class, area);
        }
        return jdbc.queryForList(
                "SELECT DISTINCT EQID FROM EQIndex WHERE Area = ? AND tableDep = ? ORDER BY EQID",
                String.class, area, mappedDep);
    }

    @Override
    public List<String> getPersons() {
        return jdbc.queryForList("""
                SELECT User_Name FROM AccountTable_Active
                WHERE GROUP_3 != '0' AND (Job_Title = 'Leader' OR Job_Title IS NULL)
                ORDER BY User_Name
                """, String.class);
    }

    @Override
    public List<Map<String, Object>> getEvents(int year, int month, String dep, String area,
                                                boolean showPre, boolean showTempWork, boolean showPM) {
        List<Map<String, Object>> result = new ArrayList<>();

        String monthStart = String.format("%d/%02d/01 00:00:00", year, month);
        String monthEnd = String.format("%d/%02d/01 00:00:00",
                month == 12 ? year + 1 : year, month == 12 ? 1 : month + 1);

        String mappedDep = mapDep(dep);
        String depCondition = mappedDep == null ? "" : " AND tableDep = ? ";
        String areaCondition = "0".equals(area) ? "" : " AND Area = ? ";

        // Period 篩選（對應原本 funcPre 的 strSentence_Period）
        String periodCondition = "";
        if (showPre && !showTempWork) periodCondition = " AND Period != '0' ";
        else if (!showPre && showTempWork) periodCondition = " AND Period = '0' ";

        if (showPre || showTempWork) {
            String sql = """
                    SELECT
                        Sequence AS sequence, EQID AS eqid, SubEQ AS subEQ,
                        WorkInfo AS workInfo, StopEQReason AS stopEQReason,
                        Prearranged_Person AS prearrangedPerson, Priority AS priority,
                        Period AS period, LendStatus AS lendStatus,
                        PMTableSequence AS pmTableSequence, ExtendSequence AS extendSequence,
                        DATE_FORMAT(StartTime, '%Y/%m/%d') AS dateStr,
                        DATE_FORMAT(StartTime, '%H:%i') AS startTimeStr,
                        DATE_FORMAT(EndTime, '%H:%i') AS endTimeStr,
                        StartTime AS startTimeFull,
                        'pre' AS type
                    FROM Table_JobSchedule
                    WHERE Active = 1 AND StartTime >= ? AND StartTime < ?
                    """ + periodCondition + depCondition + areaCondition + """
                    ORDER BY ExtendSequence ASC, StartTime ASC
                    """;
            result.addAll(runQuery(sql, mappedDep, area, depCondition, areaCondition, monthStart, monthEnd));
        }

        if (showPM) {
            String sql = """
                    SELECT
                        Table_PM.Sequence AS sequence, Table_PM.EQID AS eqid, Table_PM.SubEQ AS subEQ,
                        Table_PM.Problem AS stopEQReason, Table_PM.PMPeople AS prearrangedPerson,
                        DATE_FORMAT(Table_PM.StartTime, '%Y/%m/%d') AS dateStr,
                        DATE_FORMAT(Table_PM.StartTime, '%H:%i') AS startTimeStr,
                        DATE_FORMAT(Table_PM.FinishTime, '%H:%i') AS endTimeStr,
                        Table_PM.StartTime AS startTimeFull,
                        'pm' AS type
                    FROM Table_PM
                    WHERE Table_PM.Active = 1 AND Table_PM.StartTime >= ? AND Table_PM.StartTime < ?
                    """ + areaCondition.replace("Area", "Table_PM.Area")
                       + depCondition.replace("tableDep", "Table_PM.tableDep") + """
                    ORDER BY Table_PM.StartTime ASC
                    """;
            result.addAll(runQuery(sql, mappedDep, area, depCondition, areaCondition, monthStart, monthEnd));
        }

        return result;
    }

    /** 對應 MyModule1.funcTableDep()：1→'11'(AMHS1), 2→'12'(AMHS2), 0/其他→不篩選(null)。 */
    private String mapDep(String dep) {
        if (dep == null) return null;
        return switch (dep.trim()) {
            case "1" -> "11";
            case "2" -> "12";
            default -> null; // 0=ALL 或未知值：不套用篩選
        };
    }

    private List<Map<String, Object>> runQuery(String sql, String mappedDep, String area,
                                                String depCondition, String areaCondition,
                                                String monthStart, String monthEnd) {
        List<Object> params = new ArrayList<>(List.of(monthStart, monthEnd));
        if (!depCondition.isEmpty()) params.add(mappedDep);
        if (!areaCondition.isEmpty()) params.add(area);
        return jdbc.queryForList(sql, params.toArray());
    }
}
