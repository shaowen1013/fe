package com.shaowen.fe.service;

import java.util.Map;

/**
 * 預排工作 CRUD 服務介面。
 * 對應 8-2.JobSchedule.aspx.cs 的 CRUD 邏輯。
 */
public interface JobScheduleService {

    /** 查詢單筆（Initial_Job） */
    Map<String, Object> getJob(Long sequence);

    /** 新增（funcSave 新增分支） */
    Long createJob(Map<String, Object> body);

    /** 修改（funcSave 修改分支） */
    void updateJob(Long sequence, Map<String, Object> body);

    /** 軟刪除 Active=0（btnDelete_Click） */
    void deleteJob(Long sequence);

    /**
     * 遞延（btnExtend_Click）：
     * 新增一筆後，將原筆的 ExtendSequence 更新為新筆的 Sequence。
     * 需使用 @Transactional 確保兩步驟一致性。
     */
    Long extendJob(Map<String, Object> body);
}
