package com.shaowen.fe.service;

import com.shaowen.fe.dto.LoginRequest;
import com.shaowen.fe.dto.LoginResponse;

/**
 * 登入驗證服務介面。
 * Controller 依賴此介面，不依賴具體實作，方便日後替換或測試。
 */
public interface AuthService {

    /**
     * 驗證帳號密碼，成功回傳 JWT token 與使用者資訊。
     * 對應原本 Login.aspx.cs btnLogin_Click 的驗證邏輯。
     *
     * @param request 包含 userId 與 password
     * @return LoginResponse（token + userInfo）
     * @throws org.springframework.security.authentication.BadCredentialsException 帳密錯誤時拋出
     */
    LoginResponse login(LoginRequest request);
}
