package com.shaowen.fe.controller;

import com.shaowen.fe.service.HandOverService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Map;
import java.util.UUID;

/** 對應 3-1.HandOver_Search.aspx（查詢）與 3-2.HandOver_Act.aspx（新增/修改）。 */
@RestController
@RequestMapping("/api/handover")
public class HandOverController {

    @Autowired
    private HandOverService handOverService;

    @Value("${app.upload.handover-dir:uploads/handover}")
    private String uploadDir;

    @GetMapping("/lookups")
    public ResponseEntity<Map<String, Object>> lookups() {
        return ResponseEntity.ok(handOverService.getLookups());
    }

    @GetMapping
    public ResponseEntity<Map<String, Object>> search(@RequestParam Map<String, String> params) {
        return ResponseEntity.ok(handOverService.search(params));
    }

    @GetMapping("/{sequence}")
    public ResponseEntity<Map<String, Object>> getOne(@PathVariable Long sequence) {
        return ResponseEntity.ok(handOverService.getOne(sequence));
    }

    @PostMapping
    public ResponseEntity<Map<String, Object>> create(@RequestBody Map<String, Object> body,
                                                        Authentication authentication) {
        Long sequence = handOverService.create(authentication.getName(), body);
        return ResponseEntity.ok(Map.of("sequence", sequence));
    }

    @PutMapping("/{sequence}")
    public ResponseEntity<Void> update(@PathVariable Long sequence, @RequestBody Map<String, Object> body) {
        handOverService.update(sequence, body);
        return ResponseEntity.ok().build();
    }

    /** 上傳圖片1/2 與附件（皆選填）。 */
    @PostMapping("/{sequence}/files")
    public ResponseEntity<Map<String, Object>> uploadFiles(
            @PathVariable Long sequence,
            @RequestParam(required = false) MultipartFile image1,
            @RequestParam(required = false) MultipartFile image2,
            @RequestParam(required = false) MultipartFile attachment) throws IOException {

        String f1 = saveFile(sequence, image1);
        String f2 = saveFile(sequence, image2);
        String fFile = saveFile(sequence, attachment);

        handOverService.updateFileNames(sequence, f1, f2, fFile);

        return ResponseEntity.ok(Map.of(
                "fileName", f1 == null ? "" : f1,
                "fileName2", f2 == null ? "" : f2,
                "fileNameFile", fFile == null ? "" : fFile
        ));
    }

    private String saveFile(Long sequence, MultipartFile file) throws IOException {
        if (file == null || file.isEmpty()) return null;
        Path dir = Path.of(uploadDir, sequence.toString());
        Files.createDirectories(dir);
        String original = file.getOriginalFilename() == null ? "file" : file.getOriginalFilename();
        String ext = original.contains(".") ? original.substring(original.lastIndexOf('.')) : "";
        String storedName = UUID.randomUUID() + ext;
        Files.copy(file.getInputStream(), dir.resolve(storedName), StandardCopyOption.REPLACE_EXISTING);
        return sequence + "/" + storedName;
    }
}
