package com.shaowen.fe.service;

import java.util.List;
import java.util.Map;

/**
 * 行事曆服務介面。對應 8-1.WebCalendar.aspx 的查詢邏輯。
 *
 * 重要：表單歸屬（tableDep）欄位在資料庫中實際存放的是 DepIndex.DEP_NO 這種代碼
 * （AMHS1=11, AMHS2=12...），但畫面上為求簡潔改用 0=ALL/1=AMHS1/2=AMHS2 的簡化代碼。
 * 這與原系統 MyModule1.funcTableDep() 的轉換規則一致：1→'11'、2→'12'、0→不篩選。
 * 呼叫端傳入的 dep 一律是簡化代碼，實作內部負責轉換為真正存進資料庫的代碼。
 */
public interface CalendarService {

    /** 廠別清單（SqlDataSourceArea） */
    List<String> getAreas();

    /** 設備清單（依廠別 + 表單歸屬篩選，dep 為簡化代碼 0/1/2） */
    List<String> getEqList(String area, String dep);

    /** 預排作業人員清單（SqlDataSource5） */
    List<String> getPersons();

    /**
     * 月曆事件查詢（對應 DayRender → funcPre / funcHum）。
     * dep 為簡化代碼（0=ALL, 1=AMHS1, 2=AMHS2），內部會轉換為實際存放的代碼再查詢。
     */
    List<Map<String, Object>> getEvents(int year, int month, String dep, String area,
                                         boolean showPre, boolean showTempWork, boolean showPM);
}
