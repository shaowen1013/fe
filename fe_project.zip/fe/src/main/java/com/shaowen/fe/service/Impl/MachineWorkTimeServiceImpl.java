package com.shaowen.fe.service.Impl;

import com.shaowen.fe.service.MachineWorkTimeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class MachineWorkTimeServiceImpl implements MachineWorkTimeService {

    @Autowired
    private JdbcTemplate jdbc;

    @Override
    public Map<String, Object> searchPersonal(Map<String, String> p) {
        StringBuilder where = new StringBuilder(" WHERE Table_MachineStatus.Active = 1 ");
        List<Object> args = new ArrayList<>();

        String startTime = orDefault(p.get("startTime"), "1990-01-01 00:00:00");
        String endTime = orDefault(p.get("endTime"), "2999-01-01 00:00:00");
        where.append(" AND Table_MachineStatus.StartTime BETWEEN ? AND ? ");
        args.add(startTime);
        args.add(endTime);

        String userName = trim(p.get("userName"));
        if (!userName.isEmpty()) {
            where.append(" AND Table_MachineStatus.Pricipal_Person LIKE ? ");
            args.add("%" + userName + "%");
        }
        String isFinished = trim(p.get("isFinished"));
        if (!isFinished.isEmpty() && !"-1".equals(isFinished)) {
            where.append(" AND Table_MachineStatus.isFinished = ? ");
            args.add("1".equals(isFinished));
        }

        String sql = """
                SELECT Sequence, Title, Area, EQID, StartTime, FinishTime,
                       TIMESTAMPDIFF(MINUTE, StartTime, FinishTime) AS workMinutes,
                       Pricipal_Person, Caller_Person, isFinished
                FROM Table_MachineStatus
                """ + where + " ORDER BY Sequence DESC";

        List<Map<String, Object>> rows = jdbc.queryForList(sql, args.toArray());
        int totalMinutes = mergedMinutes(rows, "StartTime", "FinishTime");

        Map<String, Object> result = new HashMap<>();
        result.put("rows", rows);
        result.put("totalMinutes", totalMinutes);
        return result;
    }

    @Override
    public List<Map<String, Object>> searchAll(Map<String, String> p) {
        String startTime = orDefault(p.get("startTime"), "1990-01-01 00:00:00");
        String endTime = orDefault(p.get("endTime"), "2999-01-01 00:00:00");

        List<Map<String, Object>> people = jdbc.queryForList("""
                SELECT Group_4 AS dep, User_Name AS userName
                FROM AccountTable_Active
                WHERE Group_3 != '0' AND (Job_Title = 'Leader' OR Job_Title IS NULL)
                ORDER BY Group_4
                """);

        List<Map<String, Object>> result = new ArrayList<>();
        for (Map<String, Object> person : people) {
            String userName = (String) person.get("userName");
            List<Map<String, Object>> rows = jdbc.queryForList("""
                    SELECT StartTime, FinishTime FROM Table_MachineStatus
                    WHERE Pricipal_Person LIKE ? AND StartTime BETWEEN ? AND ? AND Active = 1
                    """, "%" + userName + "%", startTime, endTime);

            int totalMinutes = mergedMinutes(rows, "StartTime", "FinishTime");

            Map<String, Object> row = new HashMap<>();
            row.put("dep", person.get("dep"));
            row.put("userName", userName);
            row.put("totalMinutes", totalMinutes);
            result.add(row);
        }
        return result;
    }

    /** 與 PmWorkTimeServiceImpl 相同的區間合併演算法，避免重疊時段重複計算。 */
    private int mergedMinutes(List<Map<String, Object>> rows, String startCol, String endCol) {
        List<long[]> intervals = new ArrayList<>();
        for (Map<String, Object> row : rows) {
            LocalDateTime s = toLdt(row.get(startCol));
            LocalDateTime e = toLdt(row.get(endCol));
            if (s == null || e == null) continue;
            long sm = s.toEpochSecond(ZoneOffset.UTC) / 60;
            long em = e.toEpochSecond(ZoneOffset.UTC) / 60;
            if (em <= sm) continue;
            intervals.add(new long[]{sm, em});
        }
        if (intervals.isEmpty()) return 0;
        intervals.sort(Comparator.comparingLong(a -> a[0]));

        long total = 0;
        long curStart = intervals.get(0)[0];
        long curEnd = intervals.get(0)[1];
        for (int i = 1; i < intervals.size(); i++) {
            long[] iv = intervals.get(i);
            if (iv[0] <= curEnd) {
                curEnd = Math.max(curEnd, iv[1]);
            } else {
                total += (curEnd - curStart);
                curStart = iv[0];
                curEnd = iv[1];
            }
        }
        total += (curEnd - curStart);
        return (int) total;
    }

    private LocalDateTime toLdt(Object v) {
        if (v == null) return null;
        if (v instanceof LocalDateTime ldt) return ldt;
        if (v instanceof Timestamp ts) return ts.toLocalDateTime();
        return null;
    }

    private String trim(String s) { return s == null ? "" : s.trim(); }
    private String orDefault(String s, String def) { return (s == null || s.isBlank()) ? def : s; }
}
