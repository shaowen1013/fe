package com.shaowen.fe.service;

import java.util.List;
import java.util.Map;

/**
 * PM 人員工時模組服務介面。
 * 對應 5-3.PM_PersonWorkTime_Search.aspx.cs（個人/全體）與
 * 5-4.PM_PersonWorkTime_ByGroup.aspx.cs（依部門統計表單類型次數）。
 */
public interface PmWorkTimeService {

    /**
     * 個人模式查詢（對應 RadioButtonList1=1）。
     * params 可含：userName（人員姓名，或整組時傳入部門代碼由 useDeptMembers 展開）、
     * useDeptMembers（true 時 userName 視為部門代碼，展開為該部門全部人員 OR 查詢）、
     * tableType, tableDep, statusNow, isErr, isErrClear, startTime, endTime
     *
     * 回傳 rows（清單）與 totalMinutesFiltered / totalMinutesRealPM
     * （對應 lblWorkingTime_Filter / lblWorkingTime_RealPM_Filter，
     *  以區間合併演算法計算，避免同一人多筆重疊工作時段被重複計算）。
     */
    Map<String, Object> searchPersonal(Map<String, String> params);

    /**
     * 全體模式查詢（對應 RadioButtonList1=0）。
     * 針對每一位非主管人員，計算：全部作業時間、實際作業時間、前置、後復、
     * 工作負荷率、AMHS/AINT/SS 佔比。
     * 因需對每人執行多次區間合併查詢，人數較多時查詢時間會較長。
     */
    List<Map<String, Object>> searchAll(Map<String, String> params);

    /** 依部門統計各表單型態的紀錄筆數矩陣（對應 5-4 getCounts + PIVOT），含 Total 列。 */
    List<Map<String, Object>> groupMatrix(String dep, String startTime, String endTime);

    /** 依部門代碼（Group_4）取得人員姓名清單（對應 getNames） */
    List<String> getDepMembers(String dep);
}
