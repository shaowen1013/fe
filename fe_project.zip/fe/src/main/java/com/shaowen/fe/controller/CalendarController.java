package com.shaowen.fe.controller;

import com.shaowen.fe.service.CalendarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 對應 8-1.WebCalendar.aspx 的後端邏輯：
 * - 廠別清單（SqlDataSourceArea）
 * - 設備清單（依廠別 + 表單歸屬篩選）
 * - 月曆事件（預排工作 / 臨時工作 / PM項目）
 * - 作業人員清單（SqlDataSource5）
 *
 * Controller 只負責參數轉換與呼叫 Service，SQL 與商業邏輯集中在 CalendarServiceImpl
 * （修正先前版本 Controller 直接內嵌 SQL、未使用既有 Service 層的不一致問題）。
 */
@RestController
@RequestMapping("/api/calendar")
public class CalendarController {

    @Autowired
    private CalendarService calendarService;

    @GetMapping("/areas")
    public ResponseEntity<List<String>> getAreas() {
        return ResponseEntity.ok(calendarService.getAreas());
    }

    @GetMapping("/eq-list")
    public ResponseEntity<List<String>> getEqList(@RequestParam(defaultValue = "") String area,
                                                   @RequestParam(defaultValue = "0") String dep) {
        return ResponseEntity.ok(calendarService.getEqList(area, dep));
    }

    @GetMapping("/persons")
    public ResponseEntity<List<String>> getPersons() {
        return ResponseEntity.ok(calendarService.getPersons());
    }

    /**
     * 月曆事件查詢，對應 Calendar2 的 DayRender 邏輯。
     *
     * @param year         年
     * @param month        月（1-12）
     * @param dep          表單歸屬簡化代碼（0=ALL, 1=AMHS1, 2=AMHS2）
     * @param area         廠別（0=不篩選）
     * @param showPre      顯示預排工作
     * @param showTempWork 顯示臨時工作
     * @param showPM       顯示PM項目
     */
    @GetMapping("/events")
    public ResponseEntity<List<Map<String, Object>>> getEvents(
            @RequestParam int year, @RequestParam int month,
            @RequestParam(defaultValue = "0") String dep, @RequestParam(defaultValue = "0") String area,
            @RequestParam(defaultValue = "true") boolean showPre,
            @RequestParam(defaultValue = "true") boolean showTempWork,
            @RequestParam(defaultValue = "false") boolean showPM) {
        return ResponseEntity.ok(
                calendarService.getEvents(year, month, dep, area, showPre, showTempWork, showPM));
    }
}
