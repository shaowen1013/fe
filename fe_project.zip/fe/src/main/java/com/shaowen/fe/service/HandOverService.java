package com.shaowen.fe.service;

import java.util.List;
import java.util.Map;

/**
 * 交接班服務介面。
 * 對應 3-1.HandOver_Search.aspx.cs（查詢）與 3-2.HandOver_Act.aspx.cs（新增/修改）。
 * 此模組沒有歷史版本表（無 Table_HandOver_History），修改為直接覆寫現行資料，
 * ModifyContext 由使用者手動填寫修改說明（非系統自動記錄版本）。
 */
public interface HandOverService {

    /** 下拉選單：areas, types（分類，原系統為寫死選項） */
    Map<String, Object> getLookups();

    /**
     * 查詢清單（對應 InitialGridView）。
     * params 可含：tableDep(簡化代碼 0/1/2)、status(0=追蹤中/1=已完成/2=全部)、keyword、group4
     * 原系統用 UNION 兩個條件相同的 SELECT 只是為了讓 Top_=1 且未過期的項目排序上浮，
     * 這裡改用單一查詢 + ORDER BY Top_ DESC 達到相同效果。
     */
    Map<String, Object> search(Map<String, String> params);

    /** 查詢單筆 */
    Map<String, Object> getOne(Long sequence);

    /** 新增（對應 Actions=a） */
    Long create(String userId, Map<String, Object> body);

    /** 修改（對應 Actions=m，直接覆寫，無版本歷史） */
    void update(Long sequence, Map<String, Object> body);

    /** 更新檔案欄位（圖片1/2 + 附件） */
    void updateFileNames(Long sequence, String fileName, String fileName2, String fileNameFile);
}
