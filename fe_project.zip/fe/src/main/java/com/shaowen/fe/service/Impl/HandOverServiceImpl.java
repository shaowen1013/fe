package com.shaowen.fe.service.Impl;

import com.shaowen.fe.service.HandOverService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

@Service
public class HandOverServiceImpl implements HandOverService {

    @Autowired
    private JdbcTemplate jdbc;

    /** 對應 3-2.HandOver_Act.aspx 的 ddlType 選項（原系統寫死於畫面，沒有資料表）。 */
    private static final List<String> TYPES = List.of(
            "請選擇", "注意", "教學", "校點", "CST鎖棚(PORT)",
            "空儲(PORT)鎖棚(PORT)", "儲位(PORT)已解", "結束", "其他");

    @Override
    public Map<String, Object> getLookups() {
        Map<String, Object> result = new HashMap<>();
        result.put("areas", jdbc.queryForList(
                "SELECT Area FROM AreaIndex WHERE sequence > -1 ORDER BY sequence", String.class));
        result.put("types", TYPES);
        return result;
    }

    @Override
    public Map<String, Object> search(Map<String, String> p) {
        StringBuilder where = new StringBuilder(" WHERE Table_HandOver.Active = 1 ");
        List<Object> args = new ArrayList<>();

        String status = trim(p.get("status"));
        if ("0".equals(status)) {
            where.append(" AND isFinished = 0 ");
        } else if ("1".equals(status)) {
            where.append(" AND isFinished = 1 ");
        } // "2" = 顯示全部，不加條件

        String keyword = trim(p.get("keyword"));
        if (!keyword.isEmpty()) {
            where.append(""" 
                    AND (Table_HandOver.Area LIKE ? OR Table_HandOver.Title LIKE ?
                         OR Table_HandOver.Things LIKE ? OR Table_HandOver.Type_ LIKE ?
                         OR Table_HandOver.ModifyContext LIKE ?)
                    """);
            String kw = "%" + keyword + "%";
            for (int i = 0; i < 5; i++) args.add(kw);
        }

        String mappedDep = mapDep(trim(p.get("tableDep")));
        if (mappedDep != null) {
            where.append(" AND Table_HandOver.tableDep = ? ");
            args.add(mappedDep);
        }

        String group4 = trim(p.get("group4"));
        if (!group4.isEmpty() && !group4.contains("AMHS")) {
            // 保留擴充空間：若未來需要依部門限制可見範圍，可在此加條件（原系統無此限制）。
        }

        String sql = """
                SELECT Table_HandOver.*, AccountTable_Active.User_Name AS creatorName
                FROM Table_HandOver
                LEFT JOIN AccountTable_Active ON AccountTable_Active.User_ID = Table_HandOver.User_ID
                """ + where + " ORDER BY Table_HandOver.Top_ DESC, Table_HandOver.Sequence DESC";

        List<Map<String, Object>> rows = jdbc.queryForList(sql, args.toArray());

        Map<String, Object> result = new HashMap<>();
        result.put("rows", rows);
        result.put("total", rows.size());
        return result;
    }

    @Override
    public Map<String, Object> getOne(Long sequence) {
        List<Map<String, Object>> rows = jdbc.queryForList("""
                SELECT Table_HandOver.*, AccountTable_Active.User_Name AS creatorName
                FROM Table_HandOver
                LEFT JOIN AccountTable_Active ON AccountTable_Active.User_ID = Table_HandOver.User_ID
                WHERE Table_HandOver.Sequence = ?
                """, sequence);
        if (rows.isEmpty()) throw new NoSuchElementException("查無此交接資料：" + sequence);
        return rows.get(0);
    }

    @Override
    @Transactional
    public Long create(String userId, Map<String, Object> body) {
        String sql = """
                INSERT INTO Table_HandOver
                    (User_ID, InsertDate, Area, DueDay, Title, Things, ModifyContext,
                     Active, isPublic, isFinished, tableDep, Type_, Top_)
                VALUES (?, CURDATE(), ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?)
                """;
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbc.update(con -> {
            PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            int i = 1;
            ps.setString(i++, userId);
            ps.setString(i++, str(body, "area"));
            ps.setString(i++, str(body, "dueDay"));
            ps.setString(i++, str(body, "title"));
            ps.setString(i++, str(body, "things"));
            ps.setString(i++, str(body, "modifyContext"));
            ps.setBoolean(i++, Boolean.TRUE.equals(body.get("isPublic")));
            ps.setBoolean(i++, Boolean.TRUE.equals(body.get("isFinished")));
            ps.setObject(i++, body.get("tableDep"));
            ps.setString(i++, str(body, "type"));
            ps.setBoolean(i, Boolean.TRUE.equals(body.get("top")));
            return ps;
        }, keyHolder);

        Number key = keyHolder.getKey();
        return key != null ? key.longValue() : 0L;
    }

    @Override
    @Transactional
    public void update(Long sequence, Map<String, Object> body) {
        String sql = """
                UPDATE Table_HandOver SET
                    Area = ?, DueDay = ?, Title = ?, Things = ?, ModifyContext = ?,
                    isPublic = ?, isFinished = ?, tableDep = ?, Type_ = ?, Top_ = ?
                WHERE Sequence = ?
                """;
        jdbc.update(sql,
                str(body, "area"), str(body, "dueDay"), str(body, "title"), str(body, "things"),
                str(body, "modifyContext"), Boolean.TRUE.equals(body.get("isPublic")),
                Boolean.TRUE.equals(body.get("isFinished")), body.get("tableDep"), str(body, "type"),
                Boolean.TRUE.equals(body.get("top")), sequence);
    }

    @Override
    public void updateFileNames(Long sequence, String fileName, String fileName2, String fileNameFile) {
        if (fileName != null && !fileName.isBlank())
            jdbc.update("UPDATE Table_HandOver SET FileName = ? WHERE Sequence = ?", fileName, sequence);
        if (fileName2 != null && !fileName2.isBlank())
            jdbc.update("UPDATE Table_HandOver SET FileName2 = ? WHERE Sequence = ?", fileName2, sequence);
        if (fileNameFile != null && !fileNameFile.isBlank())
            jdbc.update("UPDATE Table_HandOver SET FileNameFile = ? WHERE Sequence = ?", fileNameFile, sequence);
    }

    /** 對應 MyModule1.funcTableDep()：1→'11'(AMHS1), 2→'12'(AMHS2), 0/其他→不篩選(null)。 */
    private String mapDep(String dep) {
        if (dep == null) return null;
        return switch (dep.trim()) {
            case "1" -> "11";
            case "2" -> "12";
            default -> null;
        };
    }

    private String str(Map<String, Object> body, String key) {
        Object v = body.get(key);
        return v != null ? v.toString() : "";
    }

    private String trim(String s) {
        return s == null ? "" : s.trim();
    }
}
