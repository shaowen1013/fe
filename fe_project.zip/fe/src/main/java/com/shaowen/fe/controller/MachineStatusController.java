package com.shaowen.fe.controller;

import com.shaowen.fe.service.MachineStatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 對應 2-1.Machine_New.aspx（新增）、2-2.Machine_Search.aspx（查詢，2-4 廠商報表沿用）、
 * 2-3.Machine_Show.aspx（修改/歷史）。
 */
@RestController
@RequestMapping("/api/machine-status")
public class MachineStatusController {

    @Autowired
    private MachineStatusService machineStatusService;

    @Value("${app.upload.machine-dir:uploads/machine-status}")
    private String uploadDir;

    @GetMapping("/lookups")
    public ResponseEntity<Map<String, Object>> lookups() {
        return ResponseEntity.ok(machineStatusService.getLookups());
    }

    @GetMapping("/eq-list")
    public ResponseEntity<List<String>> eqList(@RequestParam(required = false, defaultValue = "") String area) {
        return ResponseEntity.ok(machineStatusService.getEqListByArea(area));
    }

    @GetMapping
    public ResponseEntity<Map<String, Object>> search(@RequestParam Map<String, String> params) {
        return ResponseEntity.ok(machineStatusService.search(params));
    }

    @GetMapping("/{sequence}")
    public ResponseEntity<Map<String, Object>> getOne(@PathVariable Long sequence) {
        return ResponseEntity.ok(machineStatusService.getOne(sequence));
    }

    @GetMapping("/{sequence}/history")
    public ResponseEntity<List<Map<String, Object>>> history(@PathVariable Long sequence) {
        return ResponseEntity.ok(machineStatusService.getHistory(sequence));
    }

    @GetMapping("/{sequence}/history/{version}")
    public ResponseEntity<Map<String, Object>> historyVersion(@PathVariable Long sequence,
                                                                @PathVariable Integer version) {
        return ResponseEntity.ok(machineStatusService.getHistoryVersion(sequence, version));
    }

    @PostMapping
    public ResponseEntity<Map<String, Object>> create(@RequestBody Map<String, Object> body,
                                                        Authentication authentication) {
        Long sequence = machineStatusService.create(authentication.getName(), body);
        return ResponseEntity.ok(Map.of("sequence", sequence));
    }

    @PutMapping("/{sequence}")
    public ResponseEntity<Void> update(@PathVariable Long sequence,
                                        @RequestBody Map<String, Object> body,
                                        Authentication authentication) {
        machineStatusService.update(sequence, authentication.getName(), body);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/{sequence}")
    public ResponseEntity<Void> delete(@PathVariable Long sequence) {
        machineStatusService.delete(sequence);
        return ResponseEntity.ok().build();
    }

    /** 上傳圖片1/2/3與附件（皆選填），簡化說明同 PmController：不再產生伺服器端縮圖。 */
    @PostMapping("/{sequence}/files")
    public ResponseEntity<Map<String, Object>> uploadFiles(
            @PathVariable Long sequence,
            @RequestParam(required = false) MultipartFile image1,
            @RequestParam(required = false) MultipartFile image2,
            @RequestParam(required = false) MultipartFile image3,
            @RequestParam(required = false) MultipartFile attachment) throws IOException {

        String f1 = saveFile(sequence, image1);
        String f2 = saveFile(sequence, image2);
        String f3 = saveFile(sequence, image3);
        String fFile = saveFile(sequence, attachment);

        machineStatusService.updateFileNames(sequence, f1, f2, f3, fFile);

        return ResponseEntity.ok(Map.of(
                "fileName", f1 == null ? "" : f1,
                "fileName2", f2 == null ? "" : f2,
                "fileName3", f3 == null ? "" : f3,
                "fileNameFile", fFile == null ? "" : fFile
        ));
    }

    private String saveFile(Long sequence, MultipartFile file) throws IOException {
        if (file == null || file.isEmpty()) return null;
        Path dir = Path.of(uploadDir, sequence.toString());
        Files.createDirectories(dir);
        String original = file.getOriginalFilename() == null ? "file" : file.getOriginalFilename();
        String ext = original.contains(".") ? original.substring(original.lastIndexOf('.')) : "";
        String storedName = UUID.randomUUID() + ext;
        Files.copy(file.getInputStream(), dir.resolve(storedName), StandardCopyOption.REPLACE_EXISTING);
        return sequence + "/" + storedName;
    }
}
