package com.shaowen.fe.dto;

public class LoginResponse {

    private String token;
    private UserInfo userInfo;

    public LoginResponse(String token, UserInfo userInfo) {
        this.token = token;
        this.userInfo = userInfo;
    }

    public String getToken() {
        return token;
    }

    public UserInfo getUserInfo() {
        return userInfo;
    }

    /**
     * 對應原本存放在 Session 內的欄位
     * (U_ID, U_Name, Group_4, Group_3, Group_2, IsIDL, Job_Title)
     */
    public static class UserInfo {
        private String userId;
        private String userName;
        private String group4;
        private String group3;
        private String group2;
        private Boolean isIdl;
        private String jobTitle;

        public UserInfo(String userId, String userName, String group4,
                         String group3, String group2, Boolean isIdl, String jobTitle) {
            this.userId = userId;
            this.userName = userName;
            this.group4 = group4;
            this.group3 = group3;
            this.group2 = group2;
            this.isIdl = isIdl;
            this.jobTitle = jobTitle;
        }

        public String getUserId() { return userId; }
        public String getUserName() { return userName; }
        public String getGroup4() { return group4; }
        public String getGroup3() { return group3; }
        public String getGroup2() { return group2; }
        public Boolean getIsIdl() { return isIdl; }
        public String getJobTitle() { return jobTitle; }
    }
}
