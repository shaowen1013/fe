package com.shaowen.fe.controller;

import com.shaowen.fe.service.PmService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 對應 5-1.PM_System_Search.aspx（查詢清單）與 5-2.PM_System_Act.aspx（新增/修改/歷史）。
 * Controller 僅負責參數轉換與呼叫 Service，商業邏輯與 SQL 全部集中在 PmServiceImpl。
 */
@RestController
@RequestMapping("/api/pm")
public class PmController {

    @Autowired
    private PmService pmService;

    @Value("${app.upload.pm-dir:uploads/pm}")
    private String pmUploadDir;

    /** 下拉選單（表單型態 / 目前狀態 / 廠商 / 負責人...），供 5-1、5-2 共用 */
    @GetMapping("/lookups")
    public ResponseEntity<Map<String, Object>> lookups() {
        return ResponseEntity.ok(pmService.getLookups());
    }

    /** 依廠別查詢設備清單（對應 drpByArea_SelectedIndexChanged） */
    @GetMapping("/eq-list")
    public ResponseEntity<List<String>> eqList(@RequestParam(required = false, defaultValue = "") String area) {
        return ResponseEntity.ok(pmService.getEqListByArea(area));
    }

    /** 查詢清單（對應 reflash_GridView1，含分頁與 Excel 匯出前的「全部撈出」模式） */
    @GetMapping
    public ResponseEntity<Map<String, Object>> search(@RequestParam Map<String, String> params) {
        return ResponseEntity.ok(pmService.search(params));
    }

    /** 查詢單筆現行資料 */
    @GetMapping("/{sequence}")
    public ResponseEntity<Map<String, Object>> getOne(@PathVariable Long sequence) {
        return ResponseEntity.ok(pmService.getOne(sequence));
    }

    /** 歷史版本清單 */
    @GetMapping("/{sequence}/history")
    public ResponseEntity<List<Map<String, Object>>> history(@PathVariable Long sequence) {
        return ResponseEntity.ok(pmService.getHistory(sequence));
    }

    /** 單一歷史版本內容 */
    @GetMapping("/{sequence}/history/{version}")
    public ResponseEntity<Map<String, Object>> historyVersion(@PathVariable Long sequence,
                                                                @PathVariable Integer version) {
        return ResponseEntity.ok(pmService.getHistoryVersion(sequence, version));
    }

    /**
     * 新增（對應 btnNew_Click，新增分支）。
     * userId 一律取自 JWT（Authentication principal），不信任前端傳入的身分欄位，
     * 對應人姓名（ModifierName 等）由 Service 內部依 userId 查 AccountTable_Active 取得。
     */
    @PostMapping
    public ResponseEntity<Map<String, Object>> create(@RequestBody Map<String, Object> body,
                                                        Authentication authentication) {
        Long sequence = pmService.create(authentication.getName(), body);
        return ResponseEntity.ok(Map.of("sequence", sequence));
    }

    /** 修改（對應 btnNew_Click，Actions=m 分支：先寫歷史，再更新現行資料並 version+1） */
    @PutMapping("/{sequence}")
    public ResponseEntity<Void> update(@PathVariable Long sequence,
                                        @RequestBody Map<String, Object> body,
                                        Authentication authentication) {
        pmService.update(sequence, authentication.getName(), body);
        return ResponseEntity.ok().build();
    }

    /** 軟刪除（對應 GridView1_RowDeleting：Active=0 並清除 JobSchedule 關聯） */
    @DeleteMapping("/{sequence}")
    public ResponseEntity<Void> delete(@PathVariable Long sequence) {
        pmService.delete(sequence);
        return ResponseEntity.ok().build();
    }

    /**
     * 檔案上傳（對應 FileUpload1 / FileUpload2 / FileUploadFile）。
     * 簡化說明：原系統另外產生 640x480 縮圖存於獨立資料夾，此處改為僅保留原始檔，
     * 前端如需縮圖顯示可用 CSS/瀏覽器端縮放；如仍需伺服器縮圖，可於此擴充。
     */
    @PostMapping("/{sequence}/files")
    public ResponseEntity<Map<String, Object>> uploadFiles(
            @PathVariable Long sequence,
            @RequestParam(required = false) MultipartFile image1,
            @RequestParam(required = false) MultipartFile image2,
            @RequestParam(required = false) MultipartFile attachment) throws IOException {

        String fileName = saveFile(sequence, image1);
        String fileName2 = saveFile(sequence, image2);
        String fileNameFile = saveFile(sequence, attachment);

        pmService.updateFileNames(sequence, fileName, fileName2, fileNameFile);

        return ResponseEntity.ok(Map.of(
                "fileName", fileName == null ? "" : fileName,
                "fileName2", fileName2 == null ? "" : fileName2,
                "fileNameFile", fileNameFile == null ? "" : fileNameFile
        ));
    }

    private String saveFile(Long sequence, MultipartFile file) throws IOException {
        if (file == null || file.isEmpty()) return null;

        Path dir = Path.of(pmUploadDir, sequence.toString());
        Files.createDirectories(dir);

        String original = file.getOriginalFilename() == null ? "file" : file.getOriginalFilename();
        String ext = original.contains(".") ? original.substring(original.lastIndexOf('.')) : "";
        String storedName = UUID.randomUUID() + ext;

        Path target = dir.resolve(storedName);
        Files.copy(file.getInputStream(), target, StandardCopyOption.REPLACE_EXISTING);

        return sequence + "/" + storedName;
    }
}
