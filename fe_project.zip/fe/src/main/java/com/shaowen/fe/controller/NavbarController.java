package com.shaowen.fe.controller;

import com.shaowen.fe.dto.LoginResponse.UserInfo;
import com.shaowen.fe.entity.Account;
import com.shaowen.fe.repository.AccountRepository;
import com.shaowen.fe.security.JwtTokenProvider;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.crypto.SecretKey;
import java.util.Map;
import java.util.Optional;

/**
 * 對應原本 Navbar.aspx.cs 的 Page_Load。
 * 原程式由 QueryString 取 User_ID / User_Password，
 * 改為從 JWT Bearer Token 解析 userId，不再傳遞密碼。
 */
@RestController
@RequestMapping("/api/navbar")
public class NavbarController {

    private final AccountRepository accountRepository;

    @Value("${app.jwt.secret}")
    private String jwtSecret;

    public NavbarController(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    /**
     * 前端帶著 JWT token 呼叫此 API，取得使用者基本資訊供 Navbar 顯示。
     * Header: Authorization: Bearer <token>
     */
    @GetMapping("/me")
    public ResponseEntity<?> getCurrentUser(
            @RequestHeader(value = "Authorization", required = false) String authHeader) {

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("message", "未提供有效的 Token"));
        }

        String token = authHeader.substring(7);
        String userId;
        try {
            SecretKey key = Keys.hmacShaKeyFor(jwtSecret.getBytes());
            Claims claims = Jwts.parser()
                    .verifyWith(key)
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();
            userId = claims.getSubject();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("message", "Token 無效或已過期"));
        }

        Optional<Account> accountOpt = accountRepository.findByUserIdAndAccountActiveTrue(userId);
        if (accountOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("message", "查無此使用者"));
        }

        Account account = accountOpt.get();
        UserInfo userInfo = new UserInfo(
                account.getUserId(),
                account.getUserName(),
                account.getGroup4(),
                account.getGroup3(),
                account.getGroup2(),
                account.getIsIdl(),
                account.getJobTitle()
        );

        return ResponseEntity.ok(userInfo);
    }
}
