package com.shaowen.fe.service.Impl;

import com.shaowen.fe.dto.LoginRequest;
import com.shaowen.fe.dto.LoginResponse;
import com.shaowen.fe.dto.LoginResponse.UserInfo;
import com.shaowen.fe.entity.Account;
import com.shaowen.fe.repository.AccountRepository;
import com.shaowen.fe.security.JwtTokenProvider;
import com.shaowen.fe.service.AuthService;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * AuthService 的具體實作。
 * 若未來需要改為 LDAP 驗證或其他機制，只需新增另一個 impl 類別並切換注入，
 * Controller 不需要任何修改。
 */
@Service
public class AuthServiceImpl implements AuthService {

    private final AccountRepository accountRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenProvider jwtTokenProvider;

    public AuthServiceImpl(AccountRepository accountRepository,
                           PasswordEncoder passwordEncoder,
                           JwtTokenProvider jwtTokenProvider) {
        this.accountRepository = accountRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtTokenProvider = jwtTokenProvider;
    }

    /**
     * 對應原本 btnLogin_Click 的驗證流程：
     * 1. 依工號查詢啟用中帳號（參數化查詢，避免 SQL Injection）
     * 2. 驗證密碼
     * 3. 組裝使用者資訊並簽發 JWT token（取代原本 Session）
     */
    @Override
    public LoginResponse login(LoginRequest request) {
        Optional<Account> accountOpt = accountRepository
                .findByUserIdAndAccountActiveTrue(request.getUserId());

        Account account = accountOpt.orElseThrow(
                () -> new BadCredentialsException("帳號/密碼有誤"));

        if (!matchPassword(request.getPassword(), account.getUserPassword())) {
            throw new BadCredentialsException("帳號/密碼有誤");
        }

        String token = jwtTokenProvider.generateToken(account.getUserId());

        UserInfo userInfo = new UserInfo(
                account.getUserId(),
                account.getUserName(),
                account.getGroup4(),
                account.getGroup3(),
                account.getGroup2(),
                account.getIsIdl(),
                account.getJobTitle()
        );

        return new LoginResponse(token, userInfo);
    }

    /**
     * 密碼比對。
     * 優先以 BCrypt 雜湊比對（$2 開頭），過渡期相容明碼比對。
     * 建議儘快將資料庫密碼欄位遷移為 BCrypt 儲存。
     */
    private boolean matchPassword(String rawPassword, String storedPassword) {
        if (storedPassword != null && storedPassword.startsWith("$2")) {
            return passwordEncoder.matches(rawPassword, storedPassword);
        }
        return storedPassword != null && storedPassword.equals(rawPassword);
    }
}
