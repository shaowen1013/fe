package com.shaowen.fe.service.Impl;

import com.shaowen.fe.service.JobScheduleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

@Service
public class JobScheduleServiceImpl implements JobScheduleService {

    @Autowired
    private JdbcTemplate jdbc;

    @Override
    public Map<String, Object> getJob(Long sequence) {
        String sql = """
                SELECT J.*,
                       DATE_FORMAT(J.StartTime, 120) AS startTime,
                       DATE_FORMAT(J.EndTime,   120) AS endTime,
                       A.User_Name AS userName
                FROM Table_JobSchedule J
                LEFT JOIN AccountTable_Active A ON A.User_ID = J.User_ID
                WHERE J.Sequence = ?
                """;
        List<Map<String, Object>> rows = jdbc.queryForList(sql, sequence);
        if (rows.isEmpty()) throw new NoSuchElementException("查無此工作單：" + sequence);
        return rows.get(0);
    }

    @Override
    @Transactional
    public Long createJob(Map<String, Object> body) {
        String sql = """
                INSERT INTO Table_JobSchedule
                    (User_ID, tableDep, Area, EQID, SubEQ,
                     StartTime, EndTime, WorkInfo, Period,
                     StopEQReason, Priority, Prearranged_Person,
                     isNeedLend, LendStatus, Active)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
                """;
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbc.update(con -> {
            PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, str(body, "userId"));
            ps.setString(2, str(body, "tableDep"));
            ps.setString(3, str(body, "area"));
            ps.setString(4, str(body, "eqid"));
            ps.setString(5, str(body, "subEQ"));
            ps.setString(6, str(body, "startTime"));
            ps.setString(7, str(body, "endTime"));
            ps.setString(8, str(body, "workInfo"));
            ps.setString(9, str(body, "period"));
            ps.setString(10, str(body, "stopEQReason"));
            ps.setString(11, str(body, "priority"));
            ps.setString(12, str(body, "prearrangedPerson"));
            boolean needLend = Boolean.TRUE.equals(body.get("isNeedLend"));
            ps.setBoolean(13, needLend);
            if (!needLend) ps.setNull(14, java.sql.Types.INTEGER);
            else ps.setString(14, str(body, "lendStatus"));
            return ps;
        }, keyHolder);
        Number key = keyHolder.getKey();
        return key != null ? key.longValue() : 0L;
    }

    @Override
    @Transactional
    public void updateJob(Long sequence, Map<String, Object> body) {
        String sql = """
                UPDATE Table_JobSchedule SET
                    tableDep = ?, Area = ?, EQID = ?, SubEQ = ?,
                    StartTime = ?, EndTime = ?, WorkInfo = ?, Period = ?,
                    StopEQReason = ?, Priority = ?, Prearranged_Person = ?,
                    isNeedLend = ?, LendStatus = ?
                WHERE Sequence = ?
                """;
        boolean needLend = Boolean.TRUE.equals(body.get("isNeedLend"));
        jdbc.update(sql,
                str(body, "tableDep"), str(body, "area"), str(body, "eqid"), str(body, "subEQ"),
                str(body, "startTime"), str(body, "endTime"), str(body, "workInfo"), str(body, "period"),
                str(body, "stopEQReason"), str(body, "priority"), str(body, "prearrangedPerson"),
                needLend, needLend ? str(body, "lendStatus") : null,
                sequence);
    }

    @Override
    @Transactional
    public void deleteJob(Long sequence) {
        jdbc.update("UPDATE Table_JobSchedule SET Active = 0 WHERE Sequence = ?", sequence);
    }

    /**
     * 遞延：新增一筆 → 更新原筆 ExtendSequence。
     * @Transactional 確保兩步驟一起成功或一起 rollback。
     */
    @Override
    @Transactional
    public Long extendJob(Map<String, Object> body) {
        Long newSeq = createJob(body);
        Object originalSeq = body.get("originalSequence");
        jdbc.update(
                "UPDATE Table_JobSchedule SET ExtendSequence = ? WHERE Sequence = ?",
                newSeq, originalSeq);
        return newSeq;
    }

    private String str(Map<String, Object> body, String key) {
        Object v = body.get(key);
        return v != null ? v.toString() : "";
    }
}
