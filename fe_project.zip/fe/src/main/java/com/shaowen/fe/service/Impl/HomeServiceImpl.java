package com.shaowen.fe.service.Impl;

import com.shaowen.fe.service.HomeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
public class HomeServiceImpl implements HomeService {

    @Autowired
    private JdbcTemplate jdbc;

    private static final Set<String> MACHINE_SORT_FIELDS = Set.of(
            "sequence", "eqid", "eqVendor", "eqArea", "userName", "startTime", "handoverPerson");

    private static final Set<String> PM_SORT_FIELDS = Set.of(
            "sequence", "eqid", "eqVendor", "userName", "fabPrincipal", "eqPrincipal", "statusNow");

    private static final Set<String> PROPOSAL_SORT_FIELDS = Set.of(
            "sequence", "userName", "tableType", "executor", "tableStatus");

    private static final Map<String, String> MACHINE_FIELD_MAP = Map.of(
            "sequence", "Table_MachineStatus.Sequence",
            "eqid", "Table_MachineStatus.EQID",
            "eqVendor", "TMP_EQIndex.EQ_Vendor",
            "eqArea", "TMP_EQIndex.EQ_Area",
            "userName", "AccountTable_Active.User_Name",
            "startTime", "Table_MachineStatus.StartTime",
            "handoverPerson", "Table_MachineStatus.Handover_Person"
    );

    @Override
    public List<String> getUserList() {
        String sql = """
                SELECT User_Name FROM AccountTable_Active
                WHERE Group_4 LIKE 'AMHS%' AND AccountActive = 1
                ORDER BY User_Name
                """;
        return jdbc.queryForList(sql, String.class);
    }

    @Override
    public List<Map<String, Object>> getMachineNotFinished(String userName,
                                                            String sortField,
                                                            String sortDir) {
        String orderBy = buildOrderBy(sortField, sortDir, MACHINE_SORT_FIELDS,
                MACHINE_FIELD_MAP, "Table_MachineStatus.Sequence DESC");
        String sql = """
                SELECT DISTINCT
                    Table_MachineStatus.Sequence        AS sequence,
                    Table_MachineStatus.EQID            AS eqid,
                    TMP_EQIndex.EQ_Vendor               AS eqVendor,
                    TMP_EQIndex.EQ_Area                 AS eqArea,
                    AccountTable_Active.User_Name       AS userName,
                    Table_MachineStatus.StartTime       AS startTime,
                    Table_MachineStatus.Handover_Person AS handoverPerson
                FROM Table_MachineStatus
                LEFT JOIN AccountTable_Active
                    ON AccountTable_Active.User_ID = Table_MachineStatus.User_ID
                LEFT JOIN (SELECT DISTINCT EQID, EQ_Vendor, EQ_Area FROM EQIndex) AS TMP_EQIndex
                    ON Table_MachineStatus.EQID = TMP_EQIndex.EQID
                WHERE (Table_MachineStatus.Handover_Person LIKE ? OR AccountTable_Active.User_Name = ?)
                AND Active = 1 AND isFinished = 0 AND AccountTable_Active.AccountActive = 1
                """ + orderBy;
        return jdbc.queryForList(sql, "%" + userName + "%", userName);
    }

    @Override
    public List<Map<String, Object>> getPMNotFinished(String userName,
                                                       String sortField,
                                                       String sortDir) {
        String orderBy = buildOrderBy(sortField, sortDir, PM_SORT_FIELDS,
                Map.of(), "Table_PM.Sequence DESC");
        String sql = """
                SELECT
                    Table_PM.Sequence                   AS sequence,
                    Table_PM.EQID                       AS eqid,
                    TMP_EQIndex.EQ_Vendor               AS eqVendor,
                    AccountTable_Active.User_Name       AS userName,
                    Table_PM.FabPrincipal               AS fabPrincipal,
                    Table_PM.EQPrincipal                AS eqPrincipal,
                    Table_Status.StatusNow_Sequence     AS statusNow
                FROM Table_PM
                LEFT JOIN AccountTable_Active ON AccountTable_Active.User_ID = Table_PM.User_ID
                LEFT JOIN Table_Status ON Table_Status.StatusNow_Sequence = Table_PM.StatusNow
                LEFT JOIN (SELECT DISTINCT EQID, EQ_Vendor FROM EQIndex) AS TMP_EQIndex
                    ON Table_PM.EQID = TMP_EQIndex.EQID
                LEFT JOIN Table_PM_TableType ON Table_PM.TableType = Table_PM_TableType.TableType_Sequence
                WHERE Active = '1' AND isErr = 'True' AND isErrClear = 'False'
                AND (FabPrincipal LIKE ? OR EQPrincipal LIKE ? OR AccountTable_Active.User_Name = ?)
                AND AccountTable_Active.AccountActive = 1
                """ + orderBy;
        String like = "%" + userName + "%";
        return jdbc.queryForList(sql, like, like, userName);
    }

    @Override
    public List<Map<String, Object>> getProposalNotFinished(String userName,
                                                             String sortField,
                                                             String sortDir) {
        String orderBy = buildOrderBy(sortField, sortDir, PROPOSAL_SORT_FIELDS,
                Map.of(), "Table_Proposal.Sequence DESC");
        String sql = """
                SELECT
                    Table_Proposal.Sequence                     AS sequence,
                    AccountTable_Active.User_Name               AS userName,
                    Table_Proposal_TableType.TableType_Sequence AS tableType,
                    Table_Proposal.Executor                     AS executor,
                    Table_Proposal_TableStatus.TableStatus      AS tableStatus
                FROM Table_Proposal
                LEFT JOIN AccountTable_Active ON AccountTable_Active.User_ID = Table_Proposal.User_ID
                LEFT JOIN Table_Proposal_TableStatus
                    ON Table_Proposal_TableStatus.TableStatus = Table_Proposal.TableStatus
                LEFT JOIN Table_Proposal_TableType
                    ON Table_Proposal_TableType.TableType_Sequence = Table_Proposal.TableType
                WHERE Active = '1' AND Executor = ? AND TableStatus_Sequence != 6
                AND AccountTable_Active.AccountActive = 1
                """ + orderBy;
        return jdbc.queryForList(sql, userName);
    }

    private String buildOrderBy(String sortField, String sortDir,
                                 Set<String> allowedFields,
                                 Map<String, String> fieldMap,
                                 String defaultOrder) {
        String safeDir = "DESC".equalsIgnoreCase(sortDir) ? "DESC" : "ASC";
        if (sortField == null || sortField.isBlank() || !allowedFields.contains(sortField)) {
            return " ORDER BY " + defaultOrder;
        }
        String sqlField = fieldMap.getOrDefault(sortField, sortField);
        return " ORDER BY " + sqlField + " " + safeDir;
    }
}
