package com.shaowen.fe.service;

import java.util.List;
import java.util.Map;

/**
 * 機況主檔服務介面。
 * 對應 2-1.Machine_New.aspx.cs（新增）、2-2.Machine_Search.aspx.cs（查詢，2-4 廠商報表沿用同一查詢）、
 * 2-3.Machine_Show.aspx.cs（修改/歷史）。
 */
public interface MachineStatusService {

    /** 下拉選單/篩選用清單：areas, vendors, handoverPersons, creators, deps */
    Map<String, Object> getLookups();

    /** 依廠別查詢設備清單（僅 EQ_Vendor 不為空者） */
    List<String> getEqListByArea(String area);

    /**
     * 查詢清單（對應 funcSearch，2-4 廠商報表也走這個方法，只是前端只帶 vendor 相關參數）。
     * params 可含：tableDep(0/1/2/3), creatorDep(0/10/20/30), startTime, endTime,
     * alarmCode, cstId, isFinished, area, eqid, vendor, handoverPerson, creator,
     * disableSomeWorks(排除工事/清潔/量測等標題), sequence, searchTitle, contextSearch, group4
     */
    Map<String, Object> search(Map<String, String> params);

    /** 查詢單筆現行資料 */
    Map<String, Object> getOne(Long sequence);

    /** 歷史版本清單 */
    List<Map<String, Object>> getHistory(Long sequence);

    /** 單一歷史版本內容 */
    Map<String, Object> getHistoryVersion(Long sequence, Integer version);

    /** 新增（對應 2-1 btnNew_Click） */
    Long create(String userId, Map<String, Object> body);

    /** 修改（對應 2-3 btnNew_Click：先寫歷史，再更新現行資料並 version+1） */
    void update(Long sequence, String userId, Map<String, Object> body);

    /** 軟刪除（Active=0） */
    void delete(Long sequence);

    /** 更新檔案欄位（圖片1/2/3 + 附件） */
    void updateFileNames(Long sequence, String fileName, String fileName2, String fileName3, String fileNameFile);
}
